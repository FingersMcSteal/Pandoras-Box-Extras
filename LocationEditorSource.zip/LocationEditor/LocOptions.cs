using System;

namespace TheBox.LocationEditor
{
	/// <summary>
	/// Summary description for LocOptions.
	/// </summary>
	public class LocOptions
	{
		public bool DrawStatics = true;
		public bool AlwaysOnTop = false;
		public string UOFolder = "";
		public TheBox.MapViewer.Maps Map = TheBox.MapViewer.Maps.Felucca;
		public string GoCommand = "[Go";
		public int ZoomLevel = 0;
		public System.Drawing.Point MapCenter = System.Drawing.Point.Empty;

		public LocOptions()
		{
		}
	}
}
