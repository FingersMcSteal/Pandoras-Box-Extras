using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Xml.Serialization;

namespace HueEditor
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class HueEditor : System.Windows.Forms.Form
	{
		// Edit data
		private HueChart EditChart;
		private short EditIndex;

		// Window state
		private System.Windows.Forms.FormWindowState state;
		private int OldWidth;
		private int OldHeight;

		private HuesDragData dData;
		private HueChart Origin;

		private HueEntry currentHue;
		private short currentHueIndex;

		private Editor editor;

		public ColorOptions Options;

		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem menuItem2;
		private System.Windows.Forms.OpenFileDialog OpenFile;
		private System.Windows.Forms.StatusBar Status;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Button ButtonEdit;
		private System.Windows.Forms.Label DisplayIndex;
		private System.Windows.Forms.Label DisplayHueName;
		private System.Windows.Forms.PictureBox Spectrum;
		private System.Windows.Forms.Label DisplayFile;
		private System.Windows.Forms.Button ButtonDel;
		private System.Windows.Forms.MenuItem menuItem3;
		private System.Windows.Forms.MenuItem EditClearSelection;
		private System.Windows.Forms.MenuItem EditDeleteSelection;
		private System.Windows.Forms.MenuItem FileNew;
		private System.Windows.Forms.MenuItem FileSave;
		private System.Windows.Forms.MenuItem FileSaveAs;
		private System.Windows.Forms.MenuItem menuItem7;
		private System.Windows.Forms.SaveFileDialog SaveFile;
		private System.Windows.Forms.MenuItem menuItem9;
		private System.Windows.Forms.MenuItem menuItem10;
		private System.Windows.Forms.MenuItem FileRecent1;
		private System.Windows.Forms.MenuItem FileRecent2;
		private System.Windows.Forms.MenuItem FileRecent3;
		private System.Windows.Forms.MenuItem FileRecent4;
		private System.Windows.Forms.MenuItem menuItem4;
		private System.Windows.Forms.MenuItem menuItem5;
		private System.Windows.Forms.MenuItem menuItem6;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public HueEditor()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			Options = new ColorOptions();
			LoadOptions();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(HueEditor));
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.FileNew = new System.Windows.Forms.MenuItem();
			this.menuItem2 = new System.Windows.Forms.MenuItem();
			this.FileSave = new System.Windows.Forms.MenuItem();
			this.FileSaveAs = new System.Windows.Forms.MenuItem();
			this.menuItem7 = new System.Windows.Forms.MenuItem();
			this.FileRecent1 = new System.Windows.Forms.MenuItem();
			this.FileRecent2 = new System.Windows.Forms.MenuItem();
			this.FileRecent3 = new System.Windows.Forms.MenuItem();
			this.FileRecent4 = new System.Windows.Forms.MenuItem();
			this.menuItem9 = new System.Windows.Forms.MenuItem();
			this.menuItem10 = new System.Windows.Forms.MenuItem();
			this.menuItem3 = new System.Windows.Forms.MenuItem();
			this.EditClearSelection = new System.Windows.Forms.MenuItem();
			this.EditDeleteSelection = new System.Windows.Forms.MenuItem();
			this.menuItem4 = new System.Windows.Forms.MenuItem();
			this.menuItem5 = new System.Windows.Forms.MenuItem();
			this.OpenFile = new System.Windows.Forms.OpenFileDialog();
			this.Status = new System.Windows.Forms.StatusBar();
			this.panel1 = new System.Windows.Forms.Panel();
			this.ButtonDel = new System.Windows.Forms.Button();
			this.DisplayHueName = new System.Windows.Forms.Label();
			this.DisplayIndex = new System.Windows.Forms.Label();
			this.DisplayFile = new System.Windows.Forms.Label();
			this.ButtonEdit = new System.Windows.Forms.Button();
			this.Spectrum = new System.Windows.Forms.PictureBox();
			this.SaveFile = new System.Windows.Forms.SaveFileDialog();
			this.menuItem6 = new System.Windows.Forms.MenuItem();
			this.panel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem1,
																					  this.menuItem3,
																					  this.menuItem4});
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 0;
			this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.FileNew,
																					  this.menuItem2,
																					  this.FileSave,
																					  this.FileSaveAs,
																					  this.menuItem7,
																					  this.FileRecent1,
																					  this.FileRecent2,
																					  this.FileRecent3,
																					  this.FileRecent4,
																					  this.menuItem9,
																					  this.menuItem10});
			this.menuItem1.Text = "File";
			this.menuItem1.Popup += new System.EventHandler(this.menuItem1_Popup);
			// 
			// FileNew
			// 
			this.FileNew.Index = 0;
			this.FileNew.Text = "New";
			this.FileNew.Click += new System.EventHandler(this.FileNew_Click);
			// 
			// menuItem2
			// 
			this.menuItem2.Index = 1;
			this.menuItem2.Text = "Open";
			this.menuItem2.Click += new System.EventHandler(this.menuItem2_Click);
			// 
			// FileSave
			// 
			this.FileSave.Index = 2;
			this.FileSave.Text = "Save";
			this.FileSave.Click += new System.EventHandler(this.FileSave_Click);
			// 
			// FileSaveAs
			// 
			this.FileSaveAs.Index = 3;
			this.FileSaveAs.Text = "Save As..";
			this.FileSaveAs.Click += new System.EventHandler(this.FileSaveAs_Click);
			// 
			// menuItem7
			// 
			this.menuItem7.Index = 4;
			this.menuItem7.Text = "-";
			// 
			// FileRecent1
			// 
			this.FileRecent1.Index = 5;
			this.FileRecent1.Text = "";
			this.FileRecent1.Click += new System.EventHandler(this.RecentFileClick);
			// 
			// FileRecent2
			// 
			this.FileRecent2.Index = 6;
			this.FileRecent2.Text = "";
			this.FileRecent2.Click += new System.EventHandler(this.RecentFileClick);
			// 
			// FileRecent3
			// 
			this.FileRecent3.Index = 7;
			this.FileRecent3.Text = "";
			this.FileRecent3.Click += new System.EventHandler(this.RecentFileClick);
			// 
			// FileRecent4
			// 
			this.FileRecent4.Index = 8;
			this.FileRecent4.Text = "";
			this.FileRecent4.Click += new System.EventHandler(this.RecentFileClick);
			// 
			// menuItem9
			// 
			this.menuItem9.Index = 9;
			this.menuItem9.Text = "-";
			// 
			// menuItem10
			// 
			this.menuItem10.Index = 10;
			this.menuItem10.Text = "Exit";
			// 
			// menuItem3
			// 
			this.menuItem3.Index = 1;
			this.menuItem3.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.EditClearSelection,
																					  this.EditDeleteSelection});
			this.menuItem3.Text = "Edit";
			this.menuItem3.Popup += new System.EventHandler(this.menuItem3_Popup);
			// 
			// EditClearSelection
			// 
			this.EditClearSelection.Index = 0;
			this.EditClearSelection.Text = "Clear Selection";
			this.EditClearSelection.Click += new System.EventHandler(this.EditClearSelection_Click);
			// 
			// EditDeleteSelection
			// 
			this.EditDeleteSelection.Index = 1;
			this.EditDeleteSelection.Text = "Delete Selection";
			this.EditDeleteSelection.Click += new System.EventHandler(this.EditDeleteSelection_Click);
			// 
			// menuItem4
			// 
			this.menuItem4.Index = 2;
			this.menuItem4.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem6,
																					  this.menuItem5});
			this.menuItem4.Text = "?";
			// 
			// menuItem5
			// 
			this.menuItem5.Index = 1;
			this.menuItem5.Text = "About";
			this.menuItem5.Click += new System.EventHandler(this.menuItem5_Click);
			// 
			// OpenFile
			// 
			this.OpenFile.Filter = "Mul Files (*.mul)|*.mul";
			// 
			// Status
			// 
			this.Status.Location = new System.Drawing.Point(0, 481);
			this.Status.Name = "Status";
			this.Status.Size = new System.Drawing.Size(752, 16);
			this.Status.TabIndex = 1;
			// 
			// panel1
			// 
			this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel1.Controls.Add(this.ButtonDel);
			this.panel1.Controls.Add(this.DisplayHueName);
			this.panel1.Controls.Add(this.DisplayIndex);
			this.panel1.Controls.Add(this.DisplayFile);
			this.panel1.Controls.Add(this.ButtonEdit);
			this.panel1.Controls.Add(this.Spectrum);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(752, 56);
			this.panel1.TabIndex = 3;
			// 
			// ButtonDel
			// 
			this.ButtonDel.Enabled = false;
			this.ButtonDel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.ButtonDel.Location = new System.Drawing.Point(332, 28);
			this.ButtonDel.Name = "ButtonDel";
			this.ButtonDel.Size = new System.Drawing.Size(75, 20);
			this.ButtonDel.TabIndex = 6;
			this.ButtonDel.Text = "Delete";
			this.ButtonDel.Click += new System.EventHandler(this.ButtonDel_Click);
			// 
			// DisplayHueName
			// 
			this.DisplayHueName.Location = new System.Drawing.Point(468, 8);
			this.DisplayHueName.Name = "DisplayHueName";
			this.DisplayHueName.Size = new System.Drawing.Size(196, 16);
			this.DisplayHueName.TabIndex = 5;
			// 
			// DisplayIndex
			// 
			this.DisplayIndex.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.DisplayIndex.Location = new System.Drawing.Point(416, 8);
			this.DisplayIndex.Name = "DisplayIndex";
			this.DisplayIndex.Size = new System.Drawing.Size(44, 16);
			this.DisplayIndex.TabIndex = 4;
			this.DisplayIndex.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// DisplayFile
			// 
			this.DisplayFile.Location = new System.Drawing.Point(420, 32);
			this.DisplayFile.Name = "DisplayFile";
			this.DisplayFile.Size = new System.Drawing.Size(244, 16);
			this.DisplayFile.TabIndex = 3;
			// 
			// ButtonEdit
			// 
			this.ButtonEdit.Enabled = false;
			this.ButtonEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.ButtonEdit.Location = new System.Drawing.Point(332, 4);
			this.ButtonEdit.Name = "ButtonEdit";
			this.ButtonEdit.Size = new System.Drawing.Size(75, 20);
			this.ButtonEdit.TabIndex = 1;
			this.ButtonEdit.Text = "Edit";
			this.ButtonEdit.Click += new System.EventHandler(this.ButtonEdit_Click);
			// 
			// Spectrum
			// 
			this.Spectrum.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.Spectrum.Location = new System.Drawing.Point(4, 4);
			this.Spectrum.Name = "Spectrum";
			this.Spectrum.Size = new System.Drawing.Size(320, 44);
			this.Spectrum.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.Spectrum.TabIndex = 0;
			this.Spectrum.TabStop = false;
			// 
			// SaveFile
			// 
			this.SaveFile.Filter = "Mul files (*.mul)|*.mul";
			// 
			// menuItem6
			// 
			this.menuItem6.Index = 0;
			this.menuItem6.Text = "Help";
			this.menuItem6.Click += new System.EventHandler(this.menuItem6_Click);
			// 
			// HueEditor
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(752, 497);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.Status);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.IsMdiContainer = true;
			this.Menu = this.mainMenu1;
			this.Name = "HueEditor";
			this.Text = "Hue Manager";
			this.Closing += new System.ComponentModel.CancelEventHandler(this.HueEditor_Closing);
			this.panel1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new HueEditor());
		}

		private void menuItem2_Click(object sender, System.EventArgs e)
		{
			if ( OpenFile.ShowDialog() == DialogResult.OK )
			{
				HueChart newHueChart = null;

				try
				{
					newHueChart = new HueChart( OpenFile.FileName );
				}
				catch
				{
					// Not a valid mul file
					Status.Text = "Not a valid hues file. Opening failed";
					return;
				}

				// File is good. Set it as a MDI child to this form
				newHueChart.MdiParent = this;

				// Add it to recent list
				Options.AddRecentFile( OpenFile.FileName );

				// Show the new child
				newHueChart.Show();

				// Handlers
				newHueChart.HueClicked += new HueClickedEventHandler( ChildHueClicked );
				newHueChart.DragStart += new DragStartEventHandler( BeginDrag );
				newHueChart.DropSuccesful += new DropSuccesfulEventHandler(newHueChart_DropSuccesful);

				Status.Text = "File opened correctly";
			}
		}

		

		private void BeginDrag( object sender, System.Windows.Forms.DragEventArgs e )
		{
			Origin = (HueChart) sender;
			dData = (HuesDragData) e.Data.GetData( typeof(HuesDragData) );
		}

		private HueEntry CurrentHue
		{
			get
			{
				return currentHue;
			}
			set
			{
				currentHue = value;

				// Display the name
				this.DisplayHueName.Text = new string( currentHue.Name );

				// Display the index
				this.DisplayIndex.Text = currentHueIndex.ToString();

				// Display the filename
				this.DisplayFile.Text = ((HueChart) ActiveMdiChild).FileName;

				// Display the hue
				Spectrum.Image = GetSpectrum();
			}
		}

		private Bitmap GetSpectrum()
		{
			Bitmap bmp = new Bitmap( 320, 40 );

			for ( int i = 0; i < 32; i++ )
			{
				// Get the color!
				Color color = HueEntry.ConvertToColor( currentHue.ColorTable[i] );

				for ( int x = 0; x < 10; x++ )
					for ( int y = 0; y < 40; y++ )
						bmp.SetPixel( 10*i + x, y, color );
			}

			return bmp;
		}

		private void ChildHueClicked( object sender, HueClickedEventArgs e )
		{
			ButtonEdit.Enabled = true;
			ButtonDel.Enabled = true;
			currentHueIndex = e.Index;
			CurrentHue = e.SelectedHue;

			// Set edit data
			this.EditChart = (HueChart) sender;
			this.EditIndex = e.Index;

		}

		private void ButtonDel_Click(object sender, System.EventArgs e)
		{
			if ( MessageBox.Show( this,
				"This will remove the selected hue. Do you want to proceed?",
				"Delete hue",
				MessageBoxButtons.YesNo,
				MessageBoxIcon.Question )
				== DialogResult.Yes )
				// Delete the hue on the current child
			{
				EditChart.RemoveHueAt( EditIndex );
			}
		}

		private void EditClearSelection_Click(object sender, System.EventArgs e)
		{
			try
			{
				((HueChart) this.ActiveMdiChild).ClearSelection();
			}
			catch 
			{
				// Not a hue chart selected?
			}
		}

		private void newHueChart_DropSuccesful(object sender, DropSuccesfulEventArgs e)
		{
			// First send data to the destination
			((HueChart) sender).CopyHues( Origin.GetHues( dData.HuesList ), dData.HuesList, dData.SelectionCenter );
			((HueChart) sender).Modified = true;

			// Delete the original if needed
			if ( e.RemoveOriginal )
			{
				Origin.DeleteHues( dData.HuesList );
				Origin.Modified = true;
			}	
		}

		private void menuItem3_Popup(object sender, System.EventArgs e)
		{
			HueChart child = ActiveMdiChild as HueChart;

			if ( child != null )
			{
				if ( child.Selection.Count > 0 )
				{
					this.EditDeleteSelection.Enabled = true;
					this.EditClearSelection.Enabled = true;
				}
				else
				{
					this.EditDeleteSelection.Enabled = false;
					this.EditClearSelection.Enabled = false;
				}
			}
			else
			{
				this.EditClearSelection.Enabled = false;
				this.EditDeleteSelection.Enabled = false;
			}
		}

		private void EditDeleteSelection_Click(object sender, System.EventArgs e)
		{
			( (HueChart) ActiveMdiChild ).DeleteSelection();
		}

		private void FileNew_Click(object sender, System.EventArgs e)
		{
			HueChart newHueChart = new HueChart();

			// File is good. Set it as a MDI child to this form
			newHueChart.MdiParent = this;

			// Show the new child
			newHueChart.Show();

			// Handlers
			newHueChart.HueClicked += new HueClickedEventHandler( ChildHueClicked );
			newHueChart.DragStart += new DragStartEventHandler( BeginDrag );
			newHueChart.DropSuccesful += new DropSuccesfulEventHandler(newHueChart_DropSuccesful);

			Status.Text = "New file created";
		}

		private void menuItem1_Popup(object sender, System.EventArgs e)
		{
			// Always enabled:
			this.FileNew.Enabled = true;
			this.menuItem2.Enabled = true;

			HueChart child = ActiveMdiChild as HueChart;

			if ( child != null )
			{
				// Chart to work on
				this.FileSaveAs.Enabled = true;

				if ( child.Modified )
					this.FileSave.Enabled = true;
				else
					this.FileSave.Enabled = false;				
			}
			else
			{
				this.FileSave.Enabled = false;
				this.FileSaveAs.Enabled = false;
			}

			int[] ToDelete = new int[ 4 ];
			int count = 0;

			for ( int i = 0; i < 4; i++ )
			{
				if ( ( Options.RecentFiles[ i ] != null ) && ( Options.RecentFiles[ i ] != "" ) )
				{
					if ( File.Exists( Options.RecentFiles[i] ) )
					{
						ToDelete[i] = 0;

						switch ( i )
						{
							case 0:
								this.FileRecent1.Text = Options.RecentFiles[ i ];
								this.FileRecent1.Visible = true;
								count++;
								break;
							case 1:
								this.FileRecent2.Text = Options.RecentFiles[ i ];
								this.FileRecent2.Visible = true;
								count++;
								break;
							case 2:
								this.FileRecent3.Text = Options.RecentFiles[ i ];
								this.FileRecent3.Visible = true;
								count++;
								break;
							case 3:
								this.FileRecent4.Text = Options.RecentFiles[ i ];
								this.FileRecent4.Visible = true;
								count++;
								break;
						}
					}
					else
					{
						ToDelete[i] = 1;
						switch ( i )
						{
							case 0:
								this.FileRecent1.Visible = false;
								break;
							case 1:
								this.FileRecent2.Visible = false;
								break;
							case 2:
								this.FileRecent3.Visible = false;
								break;
							case 3:
								this.FileRecent4.Visible = false;
								break;
						}
					}
				}
				else
				{
					switch ( i )
					{
						case 0:
							this.FileRecent1.Visible = false;
							break;
						case 1:
							this.FileRecent2.Visible = false;
							break;
						case 2:
							this.FileRecent3.Visible = false;
							break;
						case 3:
							this.FileRecent4.Visible = false;
							break;
					}
				}
			}

			if ( count == 0 )
				// Make second separator invisible
				this.menuItem9.Visible = false;
			else
				this.menuItem9.Visible = true;

			// Delete wrong files
			for ( int i = 0; i < 4; i++ )
			{
				if ( ToDelete[i] == 1 )
					Options.DeleteRecent( i );
			}
		}

		private void RecentFileClick( object sender, EventArgs e )
		{
			try
			{
				HueChart newHueChart = new HueChart( ((MenuItem)sender).Text );
				newHueChart.MdiParent = this;
				newHueChart.Show();
				newHueChart.HueClicked += new HueClickedEventHandler( ChildHueClicked );
				newHueChart.DragStart += new DragStartEventHandler( BeginDrag );
				newHueChart.DropSuccesful += new DropSuccesfulEventHandler(newHueChart_DropSuccesful);

				Status.Text = "File opened";
			}
			catch
			{
				Status.Text = "Could not open file";
			}
		}

		private void FileSaveAs_Click(object sender, System.EventArgs e)
		{
			if ( SaveFile.ShowDialog() == DialogResult.OK )
			{
				HueChart child = ActiveMdiChild as HueChart;

				try
				{
					child.Save( SaveFile.FileName );
					child.Modified = false;
					Status.Text = "File saved";
					Options.AddRecentFile( SaveFile.FileName );
				}
				catch
				{
					Status.Text = "Could not save the file";
				}
			}
		}

		private void FileSave_Click(object sender, System.EventArgs e)
		{
			HueChart child = ActiveMdiChild as HueChart;

			try
			{
				child.Save( child.FileName );
				child.Modified = false;
				Status.Text = "File saved";
				Options.AddRecentFile( child.FileName );
			}
			catch
			{
				Status.Text = "Could not save the file";
			}			
		}

		private void ButtonEdit_Click(object sender, System.EventArgs e)
		{
			Ultima.Client.Directory = "Hi";

			editor = new Editor( currentHue, Options.StaticID, Options.pType, Options.AnimCheck );

			//editor.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
			editor.Left = 0;
			editor.Top = 0;

			// Monitor option changes
			editor.StaticChanged += new StaticChangedEventHandler(editor_StaticChanged);

			// Monitor closing
			editor.EditEnd += new EditEndEventHandler(editor_EditEnd);
			this.Controls.Add( editor );
			editor.BringToFront();

			// Disable menus
			this.menuItem1.Enabled = false;
			this.menuItem3.Enabled = false;

			// Resize this window
			state = this.WindowState;
			OldWidth = Width;
			OldHeight = Height;

			this.Width = SystemInformation.FixedFrameBorderSize.Width + 660;
			this.Height = SystemInformation.FixedFrameBorderSize.Height + 438 +
				SystemInformation.MenuHeight;
			this.WindowState = FormWindowState.Normal;
			this.FormBorderStyle = FormBorderStyle.Fixed3D;
			this.MaximizeBox = false;
		}

		public void LoadOptions()
		{
			// Look for filename
			System.Reflection.Assembly theExe = this.GetType().Assembly;

			string file = theExe.Location;

			while ( !file.EndsWith ( "\\" ) )
				file = file.Substring(0, file.Length - 1);
			

			file += "Data\\HueEditorOptions.xml";

			if ( ! System.IO.File.Exists( file ) )
				return;

			// File exists
			XmlSerializer serializer = new XmlSerializer( typeof ( ColorOptions ) );
			System.IO.FileStream theStream = new System.IO.FileStream( file, System.IO.FileMode.Open );
			Options = (ColorOptions) serializer.Deserialize( theStream );
			theStream.Close();
		}

		public void SaveOptions()
		{
			// Look for filename
			System.Reflection.Assembly theExe = this.GetType().Assembly;

			string file = theExe.Location;

			while ( !file.EndsWith ( "\\" ) )
				file = file.Substring(0, file.Length - 1);

			file += "Data\\";

			if ( !Directory.Exists( file ) )
				Directory.CreateDirectory( file );			

			file += "HueEditorOptions.xml";

			XmlSerializer serializer = new XmlSerializer( typeof( ColorOptions ) );
			FileStream theStream = new FileStream( file, FileMode.Create );
			serializer.Serialize( theStream, (ColorOptions) Options );
			theStream.Close();
		}

		private void editor_StaticChanged(object sender, StaticChangedEventArgs e)
		{
			Options.StaticID = e.ID;
		}

		private void HueEditor_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			// Save options
			SaveOptions();

			foreach ( object o in this.MdiChildren )
			{
				if ( o is HueChart )
				{
					HueChart child = o as HueChart;

					if ( child.Modified )
					{
						// Modified
						if ( MessageBox.Show( this, string.Format( "The file {0} has been modified. Would you like to save it before closing?", child.FileName ),
							"Save file", MessageBoxButtons.YesNo, MessageBoxIcon.Question ) == DialogResult.Yes )
						{
							// Save as here
							if ( SaveFile.ShowDialog() == DialogResult.OK )
							{
								child.Save( SaveFile.FileName );
								child.Close();
							}
							else
							{
								e.Cancel = true;
								return;
							}
						}
						else
						{
							child.Close();
						}
					}
				}
			}
		}

		private void editor_EditEnd(object sender, EditEndEventArgs e)
		{
			if ( e.ApplyChanges )
			{
				EditChart.SetHueAt( e.TheHue, EditIndex );

				// Preivew
				this.CurrentHue = e.TheHue;				
			}

			// Close the panel
			this.Controls.Remove( editor );
			editor.Dispose();
			editor = null;

			// Enable
			this.menuItem1.Enabled = true;
			this.menuItem3.Enabled = true;

			WindowState = state;
			Width = OldWidth;
			Height = OldHeight;
			FormBorderStyle = FormBorderStyle.Sizable;
			MaximizeBox = true;

			this.menuItem1.Enabled = true;
			this.menuItem3.Enabled = true;
		}

		private void menuItem5_Click(object sender, System.EventArgs e)
		{
			HEAboutForm about = new HEAboutForm();
			about.ShowDialog();
		}

		private void menuItem6_Click(object sender, System.EventArgs e)
		{
			string file = this.GetType().Assembly.Location;

			while ( !file.EndsWith ( "\\" ) )
				file = file.Substring(0, file.Length - 1);
			

			file += "HEHelp.htm";

			if ( ! File.Exists( file ) )
			{
				MessageBox.Show( "The help file could not be found. Please re-install this software to fix this" );
				return;
			}

			System.Diagnostics.Process.Start( file );
		}
	}
}