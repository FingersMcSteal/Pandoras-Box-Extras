using System;
using System.Collections;

namespace HueEditor
{
	/// <summary>
	/// Summary description for HuesDragData.
	/// </summary>
	public class HuesDragData
	{
		private ArrayList huesList;
		public ArrayList HuesList
		{
			get
			{
				return huesList;
			}
		}

		private short selectionCenter;
		public short SelectionCenter
		{
			get
			{
				return selectionCenter;
			}
		}

		public HuesDragData( ArrayList selection, short center )
		{
			huesList = selection;
			selectionCenter = center;
		}
	}
}
