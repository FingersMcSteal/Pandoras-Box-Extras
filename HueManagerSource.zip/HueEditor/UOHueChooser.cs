using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace HueEditor
{
	/// <summary>
	/// Summary description for UOHueChooser.
	/// </summary>
	public class UOHueChooser : System.Windows.Forms.UserControl
	{
		private enum Axis
		{
			Red,
			Blue,
			Green
		}

		private System.Windows.Forms.PictureBox Chart;
		private System.Windows.Forms.RadioButton RadioRed;
		private System.Windows.Forms.RadioButton RadioBlue;
		private System.Windows.Forms.RadioButton RadioGreen;
		private System.Windows.Forms.TrackBar SliderRed;
		private System.Windows.Forms.TrackBar SliderBlue;
		private System.Windows.Forms.TrackBar SliderGreen;
		private System.Windows.Forms.NumericUpDown NumRed;
		private System.Windows.Forms.NumericUpDown NumBlue;
		private System.Windows.Forms.NumericUpDown NumGreen;
		private System.Windows.Forms.Panel PreviewColor;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public UOHueChooser()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitializeComponent call
			Chart.Image = m_Chart;

			AxisMode = Axis.Red;
			MakePalette();

		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Chart = new System.Windows.Forms.PictureBox();
			this.RadioRed = new System.Windows.Forms.RadioButton();
			this.RadioBlue = new System.Windows.Forms.RadioButton();
			this.RadioGreen = new System.Windows.Forms.RadioButton();
			this.SliderRed = new System.Windows.Forms.TrackBar();
			this.SliderBlue = new System.Windows.Forms.TrackBar();
			this.SliderGreen = new System.Windows.Forms.TrackBar();
			this.NumRed = new System.Windows.Forms.NumericUpDown();
			this.NumBlue = new System.Windows.Forms.NumericUpDown();
			this.NumGreen = new System.Windows.Forms.NumericUpDown();
			this.PreviewColor = new System.Windows.Forms.Panel();
			((System.ComponentModel.ISupportInitialize)(this.SliderRed)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.SliderBlue)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.SliderGreen)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.NumRed)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.NumBlue)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.NumGreen)).BeginInit();
			this.SuspendLayout();
			// 
			// Chart
			// 
			this.Chart.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.Chart.Location = new System.Drawing.Point(8, 8);
			this.Chart.Name = "Chart";
			this.Chart.Size = new System.Drawing.Size(258, 258);
			this.Chart.TabIndex = 0;
			this.Chart.TabStop = false;
			this.Chart.Paint += new System.Windows.Forms.PaintEventHandler(this.Chart_Paint);
			this.Chart.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Chart_MouseMove);
			this.Chart.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Chart_MouseDown);
			// 
			// RadioRed
			// 
			this.RadioRed.Appearance = System.Windows.Forms.Appearance.Button;
			this.RadioRed.Checked = true;
			this.RadioRed.Location = new System.Drawing.Point(272, 40);
			this.RadioRed.Name = "RadioRed";
			this.RadioRed.Size = new System.Drawing.Size(48, 24);
			this.RadioRed.TabIndex = 1;
			this.RadioRed.TabStop = true;
			this.RadioRed.Text = "Red";
			this.RadioRed.CheckedChanged += new System.EventHandler(this.RadioRed_CheckedChanged);
			// 
			// RadioBlue
			// 
			this.RadioBlue.Appearance = System.Windows.Forms.Appearance.Button;
			this.RadioBlue.Location = new System.Drawing.Point(384, 40);
			this.RadioBlue.Name = "RadioBlue";
			this.RadioBlue.Size = new System.Drawing.Size(48, 24);
			this.RadioBlue.TabIndex = 2;
			this.RadioBlue.Text = "Blue";
			this.RadioBlue.CheckedChanged += new System.EventHandler(this.RadioBlue_CheckedChanged);
			// 
			// RadioGreen
			// 
			this.RadioGreen.Appearance = System.Windows.Forms.Appearance.Button;
			this.RadioGreen.Location = new System.Drawing.Point(328, 40);
			this.RadioGreen.Name = "RadioGreen";
			this.RadioGreen.Size = new System.Drawing.Size(48, 24);
			this.RadioGreen.TabIndex = 3;
			this.RadioGreen.Text = "Green";
			this.RadioGreen.CheckedChanged += new System.EventHandler(this.RadioGreen_CheckedChanged);
			// 
			// SliderRed
			// 
			this.SliderRed.Location = new System.Drawing.Point(272, 72);
			this.SliderRed.Maximum = 31;
			this.SliderRed.Name = "SliderRed";
			this.SliderRed.Orientation = System.Windows.Forms.Orientation.Vertical;
			this.SliderRed.Size = new System.Drawing.Size(45, 168);
			this.SliderRed.TabIndex = 4;
			this.SliderRed.TickFrequency = 2;
			this.SliderRed.TickStyle = System.Windows.Forms.TickStyle.None;
			this.SliderRed.Scroll += new System.EventHandler(this.SliderRed_Scroll);
			// 
			// SliderBlue
			// 
			this.SliderBlue.Location = new System.Drawing.Point(384, 72);
			this.SliderBlue.Maximum = 31;
			this.SliderBlue.Name = "SliderBlue";
			this.SliderBlue.Orientation = System.Windows.Forms.Orientation.Vertical;
			this.SliderBlue.Size = new System.Drawing.Size(45, 168);
			this.SliderBlue.TabIndex = 5;
			this.SliderBlue.TickFrequency = 2;
			this.SliderBlue.TickStyle = System.Windows.Forms.TickStyle.None;
			this.SliderBlue.Scroll += new System.EventHandler(this.SliderBlue_Scroll);
			// 
			// SliderGreen
			// 
			this.SliderGreen.Location = new System.Drawing.Point(328, 72);
			this.SliderGreen.Maximum = 31;
			this.SliderGreen.Name = "SliderGreen";
			this.SliderGreen.Orientation = System.Windows.Forms.Orientation.Vertical;
			this.SliderGreen.Size = new System.Drawing.Size(45, 168);
			this.SliderGreen.TabIndex = 6;
			this.SliderGreen.TickFrequency = 2;
			this.SliderGreen.TickStyle = System.Windows.Forms.TickStyle.None;
			this.SliderGreen.Scroll += new System.EventHandler(this.SliderGreen_Scroll);
			// 
			// NumRed
			// 
			this.NumRed.Location = new System.Drawing.Point(272, 248);
			this.NumRed.Maximum = new System.Decimal(new int[] {
																   31,
																   0,
																   0,
																   0});
			this.NumRed.Name = "NumRed";
			this.NumRed.Size = new System.Drawing.Size(48, 20);
			this.NumRed.TabIndex = 7;
			this.NumRed.ValueChanged += new System.EventHandler(this.NumRed_ValueChanged);
			this.NumRed.Leave += new System.EventHandler(this.NumRed_Leave);
			// 
			// NumBlue
			// 
			this.NumBlue.Location = new System.Drawing.Point(384, 248);
			this.NumBlue.Maximum = new System.Decimal(new int[] {
																	31,
																	0,
																	0,
																	0});
			this.NumBlue.Name = "NumBlue";
			this.NumBlue.Size = new System.Drawing.Size(48, 20);
			this.NumBlue.TabIndex = 8;
			this.NumBlue.ValueChanged += new System.EventHandler(this.NumBlue_ValueChanged);
			this.NumBlue.Leave += new System.EventHandler(this.NumBlue_Leave);
			// 
			// NumGreen
			// 
			this.NumGreen.Location = new System.Drawing.Point(328, 248);
			this.NumGreen.Maximum = new System.Decimal(new int[] {
																	 31,
																	 0,
																	 0,
																	 0});
			this.NumGreen.Name = "NumGreen";
			this.NumGreen.Size = new System.Drawing.Size(48, 20);
			this.NumGreen.TabIndex = 9;
			this.NumGreen.ValueChanged += new System.EventHandler(this.NumGreen_ValueChanged);
			this.NumGreen.Leave += new System.EventHandler(this.NumGreen_Leave);
			// 
			// PreviewColor
			// 
			this.PreviewColor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.PreviewColor.Location = new System.Drawing.Point(272, 8);
			this.PreviewColor.Name = "PreviewColor";
			this.PreviewColor.Size = new System.Drawing.Size(160, 24);
			this.PreviewColor.TabIndex = 10;
			// 
			// UOHueChooser
			// 
			this.Controls.Add(this.PreviewColor);
			this.Controls.Add(this.NumGreen);
			this.Controls.Add(this.NumBlue);
			this.Controls.Add(this.NumRed);
			this.Controls.Add(this.SliderGreen);
			this.Controls.Add(this.SliderBlue);
			this.Controls.Add(this.SliderRed);
			this.Controls.Add(this.RadioGreen);
			this.Controls.Add(this.RadioBlue);
			this.Controls.Add(this.RadioRed);
			this.Controls.Add(this.Chart);
			this.Name = "UOHueChooser";
			this.Size = new System.Drawing.Size(440, 272);
			((System.ComponentModel.ISupportInitialize)(this.SliderRed)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.SliderBlue)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.SliderGreen)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.NumRed)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.NumBlue)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.NumGreen)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		#region Variables

		// Selected coordinates on the chart
		private int m_X;
		private int m_Y;

		// The 16 bit color
		public short Color16
		{
			get
			{
				return HueEntry.ConvertToColor16( Color.FromArgb( SliderRed.Value * 8,
					SliderGreen.Value * 8,
					SliderBlue.Value * 8 ) );
			}
			set
			{
				// Set sliders
				SliderRed.Value = ( ( value >> 10 ) & 0x1F );
				SliderGreen.Value = ( ( value >> 5 ) & 0x1F );
				SliderBlue.Value = ( value & 0x1F );

				// Set numbers
				NumRed.Value = SliderRed.Value;
				NumGreen.Value = SliderGreen.Value;
				NumBlue.Value = SliderBlue.Value;

				// Set X,Y
				switch ( AxisMode )
				{
					case Axis.Red:
						m_X = SliderGreen.Value * 8 + 4;
						m_Y = SliderBlue.Value * 8 + 4;
						break;
					case Axis.Green:
						m_X = SliderRed.Value * 8 + 4;
						m_Y = SliderBlue.Value * 8 + 4;
						break;
					case Axis.Blue:
						m_X = SliderRed.Value * 8 + 4;
						m_Y = SliderGreen.Value * 8 + 4;
						break;
				}

				MakePalette();
				Chart.Refresh();

			}
		}

		// The Axis mode
		private Axis m_AxisMode;
		private Axis AxisMode
		{
			get
			{
				return m_AxisMode;
			}
			set
			{
				if ( value != m_AxisMode )
				{
					m_AxisMode = value;
					MakePalette();
				}
			}
		}

		// The bitmap with the color chart
		private Bitmap m_Chart = new Bitmap( 256, 256 );

		#endregion

		private void Chart_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			Pen p = new Pen( Color.Gray );

			const int offset = 4;

			e.Graphics.DrawLine( p, m_X, 0, m_X, m_Y - offset - 1 );
			e.Graphics.DrawLine( p, m_X, m_Y + offset, m_X, 256 );

			e.Graphics.DrawLine( p, 0, m_Y, m_X - offset - 1, m_Y );
			e.Graphics.DrawLine( p, m_X + offset, m_Y, 256, m_Y );

			e.Graphics.DrawRectangle( p, m_X - offset, m_Y - offset, 2 * offset, 2 * offset );

			p.Dispose();
			p = null;

			// Update the preview color
			this.PreviewColor.BackColor = m_Chart.GetPixel( m_X, m_Y );
		}

		private void EnsureBounds( ref int coord )
		{
			if ( coord < 1 )
				coord = 1;
			if ( coord > 256 )
				coord = 256;
		}

		private int GetBlock( int coord )
		{
			return (int) ( ( coord - 1 ) / 8 );
		}

		private void SetCoordinates( int x, int y )
		{
			EnsureBounds( ref x );
			EnsureBounds( ref y );

			// There are the values
			int xBlock = GetBlock ( x );
			int yBlock = GetBlock ( y );

			// Set X,Y for drawing
			m_X = xBlock * 8 + 4;
			m_Y = yBlock * 8 + 4;

			switch ( AxisMode )
			{
				case Axis.Red:
					SliderGreen.Value = xBlock;
					NumGreen.Value = xBlock;
					SliderBlue.Value = yBlock;
					NumBlue.Value = yBlock;
					break;
				case Axis.Blue:
					SliderRed.Value = xBlock;
					NumRed.Value = xBlock;
					SliderGreen.Value = yBlock;
					NumGreen.Value = yBlock;
					break;
				case Axis.Green:
					SliderRed.Value = xBlock;
					NumRed.Value = xBlock;
					SliderBlue.Value = yBlock;
					NumBlue.Value = yBlock;
					break;
			}
		}

		private void DrawColorBox( int xBlock, int yBlock, Color color )
		{
			for ( int i = ( xBlock * 8 ); i < ( xBlock * 8 + 8 ); i++ )
				for ( int j = ( yBlock * 8  ); j < ( yBlock * 8 + 8 ); j++ )
					m_Chart.SetPixel( i, j, color );
		}

		private void MakePalette()
		{
			int val = 0;

			switch ( AxisMode )
			{
				case Axis.Red:
					val = SliderRed.Value;
					break;
				case Axis.Green:
					val = SliderGreen.Value;
					break;
				case Axis.Blue:
					val = SliderBlue.Value;
					break;
			}

			for ( int i = 0; i < 32; i++ )
				for ( int j = 0; j < 32; j++ )
				{
					switch ( AxisMode )
					{
						case Axis.Red:
							DrawColorBox( i, j, Color.FromArgb( val * 8, i * 8, j * 8 ) );
							break;
						case Axis.Green:
							DrawColorBox( i, j, Color.FromArgb( i * 8, val * 8, j * 8 ) );
							break;
						case Axis.Blue:
							DrawColorBox( i, j, Color.FromArgb( i * 8, j * 8, val * 8 ) );
							break;
					}
				}

			Chart.Refresh();
		}

		private void RadioRed_CheckedChanged(object sender, System.EventArgs e)
		{
			if ( RadioRed.Checked )
			{
				AxisMode = Axis.Red;
			}
		}

		private void RadioGreen_CheckedChanged(object sender, System.EventArgs e)
		{
			if ( RadioGreen.Checked ) 
			{
				AxisMode = Axis.Green;
			}
		}

		private void RadioBlue_CheckedChanged(object sender, System.EventArgs e)
		{
			if ( RadioBlue.Checked )
			{
				AxisMode = Axis.Blue;
			}
		}

		private void SliderRed_Scroll(object sender, System.EventArgs e)
		{
			NumRed.Value = SliderRed.Value;

			if ( AxisMode == Axis.Red )
			{
				MakePalette();
				return;
			}
			else
			{
				m_X = SliderRed.Value * 8 + 4;
				Chart.Refresh();
			}
		}

		private void SliderGreen_Scroll(object sender, System.EventArgs e)
		{
			NumGreen.Value = SliderGreen.Value;

			if ( AxisMode == Axis.Green )
			{
				MakePalette();
				return;
			}
			else
			{
				if ( AxisMode == Axis.Red )
					m_X = SliderGreen.Value * 8 + 4;
				else
					m_Y = SliderGreen.Value * 8 + 4;
				Chart.Refresh();
			}
		}

		private void SliderBlue_Scroll(object sender, System.EventArgs e)
		{
			NumBlue.Value = SliderBlue.Value;

			if ( AxisMode == Axis.Blue )
			{
				MakePalette();
				return;
			}
			else
			{
				m_Y = SliderBlue.Value * 8 + 4;
				Chart.Refresh();
			}
		}

		private void ChangeAxis( int y )
		{
			int val = 31 - (int) ( y / 8 );

			if ( val < 0 )
				val = 0;
			if ( val > 31 )
				val = 31;

			// Set it
			switch ( AxisMode )
			{
				case Axis.Red:
					SliderRed.Value = val;
					NumRed.Value = val;
					break;
				case Axis.Green:
					SliderGreen.Value = val;
					NumGreen.Value = val;
					break;
				case Axis.Blue:
					SliderBlue.Value = val;
					NumBlue.Value = val;
					break;
			}

			this.MakePalette();
		}

		private void Chart_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if ( e.Button == MouseButtons.Right )
			{
				// Use the right button to change the current axis plane
				ChangeAxis( e.Y );
				return;
			}
			SetCoordinates( e.X, e.Y );
			Chart.Refresh();
		}

		private void Chart_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if ( e.Button == MouseButtons.Left )
			{
				SetCoordinates( e.X, e.Y );
				Chart.Refresh();
			}

			if ( e.Button == MouseButtons.Right )
			{
				ChangeAxis( e.Y );
			}
		}

		private void NumRed_ValueChanged(object sender, System.EventArgs e)
		{
			SliderRed.Value = (int) NumRed.Value;
			SliderRed_Scroll( sender, e );		
		}

		private void NumRed_Leave(object sender, System.EventArgs e)
		{
			if ( NumRed.Value > 31 )
				NumRed.Value = 31;
			if ( NumRed.Value < 0 )
				NumRed.Value = 0;
		}

		private void NumGreen_ValueChanged(object sender, System.EventArgs e)
		{
			SliderGreen.Value = (int) NumGreen.Value;
			SliderGreen_Scroll( sender, e );
		}

		private void NumGreen_Leave(object sender, System.EventArgs e)
		{
			if ( NumGreen.Value > 31 )
				NumGreen.Value = 31;
			if ( NumGreen.Value < 0 )
				NumRed.Value = 0;
		}

		private void NumBlue_ValueChanged(object sender, System.EventArgs e)
		{
			SliderBlue.Value = (int) NumBlue.Value;
			SliderBlue_Scroll( sender, e );
		}

		private void NumBlue_Leave(object sender, System.EventArgs e)
		{
			if ( NumBlue.Value > 31 )
				NumBlue.Value = 31;
			if ( NumBlue.Value < 0 )
				NumBlue.Value = 0;
		}
	}
}
