using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using System.Threading;

namespace HueEditor
{
	/// <summary>
	/// Summary description for Editor.
	/// </summary>
	public class Editor : System.Windows.Forms.UserControl
	{
		// Animation Thread
		private System.Threading.Timer AnimTimer;
		private Bitmap[] Animation;
		private int CurrentFrame = 0;

		private PreviewType m_pType;
		private PreviewType pType
		{
			get
			{
				return m_pType;
			}
			set
			{
				if ( m_pType == value )
					return;

				if ( ( value == PreviewType.Mobile ) || ( value == PreviewType.MobileAnimation ) )
					this.AnimateCheck.Enabled = true;
				else
					this.AnimateCheck.Enabled = false;

				if ( m_pType == PreviewType.MobileAnimation )
				{
					AnimTimer.Dispose();
					AnimTimer = null;
				}

				m_pType = value;

				// Write options
				((HueEditor) FindForm() ).Options.pType = value;

				UpdatePreview();
			}
		}

		private enum Component
		{
			Red,
			Green,
			Blue
		}
		private int RedValue;
		private int GreenValue;
		private int BlueValue;

		private byte SelectedIndex = 0;
		private byte Index
		{
			set
			{
				if ( value != SelectedIndex )
				{
					SelectedIndex = value;
					Spectrum.Refresh();
				}
			}
			get
			{
				return SelectedIndex;
			}
		}

		// Events
		public event StaticChangedEventHandler StaticChanged;
		public event EditEndEventHandler EditEnd;

		// Selection
		private bool Selecting = false;

		private bool m_SelectionExists = false;
		private bool SelectionExists
		{
			get
			{
				return m_SelectionExists;
			}
			set
			{
				m_SelectionExists = value;

				SatRed.Enabled = m_SelectionExists;
				SatGreen.Enabled = m_SelectionExists;
				SatBlue.Enabled = m_SelectionExists;

				ButtonSpread.Enabled = m_SelectionExists;
			}
		}
		private byte SelectionStart;
		private byte SelectionEnd;

		private bool m_EditingColor = false;
		public bool EditingColor
		{
			get
			{
				return m_EditingColor;
			}
			set
			{
				m_EditingColor = value;

				ButtonUpdateColor.Enabled = value;
			}
		}

		// Hue
		private HueEntry TheHue;
		private Bitmap HuePreview;
		private Ultima.Hue uHue;

		private Bitmap TheSpectrum;

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox HueName;
		private System.Windows.Forms.Label HueIndex;
		private System.Windows.Forms.Label HueFileName;
		private System.Windows.Forms.PictureBox Spectrum;
		private UOHueChooser HuePalette;
		private System.Windows.Forms.Button ButtonUpdateColor;
		private System.Windows.Forms.Button ButtonSpread;
		private System.Windows.Forms.PictureBox Preview;
		private System.Windows.Forms.NumericUpDown NumStatic;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.TrackBar SatRed;
		private System.Windows.Forms.TrackBar SatGreen;
		private System.Windows.Forms.TrackBar SatBlue;
		private System.Windows.Forms.CheckBox AnimateCheck;
		private System.Windows.Forms.ComboBox PreviewList;
		private System.ComponentModel.IContainer components;

		public enum PreviewType
		{
			Item,
			Mobile,
			MobileAnimation,
			Gump
		}

		public Editor( HueEntry theHue, int staticID, PreviewType ptype, bool animcheck )
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			TheHue = (HueEntry) theHue.Clone();

			// Set the name
			HueName.Text = new string( TheHue.Name );

			MakeUltimaHue();

			// Make the spectrum
			TheSpectrum = new Bitmap( 320, 40 );
			Spectrum.Image = TheSpectrum;
			DrawSpectrum();

			NumStatic.Value = staticID;

			PreviewList.SelectedItem = 0;

			this.AnimateCheck.Checked = animcheck;

			switch ( ptype )
			{
				case PreviewType.Item:
					this.PreviewList.SelectedIndex = 0;
					break;
				case PreviewType.Gump:
					this.PreviewList.SelectedIndex = 2;
					break;
				case PreviewType.Mobile:
					this.PreviewList.SelectedIndex = 1;
					break;
				case PreviewType.MobileAnimation:
					this.PreviewList.SelectedIndex = 1;
					this.AnimateCheck.Checked = true;
					break;
			}

			this.m_pType = ptype;

			if ( pType == PreviewType.MobileAnimation )
				this.AnimateCheck.Enabled = true;

			UpdatePreview();
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Spectrum = new System.Windows.Forms.PictureBox();
			this.label1 = new System.Windows.Forms.Label();
			this.HueName = new System.Windows.Forms.TextBox();
			this.HueIndex = new System.Windows.Forms.Label();
			this.HueFileName = new System.Windows.Forms.Label();
			this.HuePalette = new UOHueChooser();
			this.ButtonUpdateColor = new System.Windows.Forms.Button();
			this.ButtonSpread = new System.Windows.Forms.Button();
			this.Preview = new System.Windows.Forms.PictureBox();
			this.NumStatic = new System.Windows.Forms.NumericUpDown();
			this.button1 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.SatRed = new System.Windows.Forms.TrackBar();
			this.SatGreen = new System.Windows.Forms.TrackBar();
			this.SatBlue = new System.Windows.Forms.TrackBar();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.PreviewList = new System.Windows.Forms.ComboBox();
			this.AnimateCheck = new System.Windows.Forms.CheckBox();
			((System.ComponentModel.ISupportInitialize)(this.NumStatic)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.SatRed)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.SatGreen)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.SatBlue)).BeginInit();
			this.SuspendLayout();
			// 
			// Spectrum
			// 
			this.Spectrum.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.Spectrum.Location = new System.Drawing.Point(12, 84);
			this.Spectrum.Name = "Spectrum";
			this.Spectrum.Size = new System.Drawing.Size(323, 42);
			this.Spectrum.TabIndex = 0;
			this.Spectrum.TabStop = false;
			this.Spectrum.Paint += new System.Windows.Forms.PaintEventHandler(this.Spectrum_Paint);
			this.Spectrum.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Spectrum_MouseUp);
			this.Spectrum.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Spectrum_MouseMove);
			this.Spectrum.MouseLeave += new System.EventHandler(this.Spectrum_MouseLeave);
			this.Spectrum.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Spectrum_MouseDown);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(4, 4);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(72, 20);
			this.label1.TabIndex = 1;
			this.label1.Text = "Hue Name:";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// HueName
			// 
			this.HueName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.HueName.Location = new System.Drawing.Point(76, 4);
			this.HueName.Name = "HueName";
			this.HueName.Size = new System.Drawing.Size(124, 20);
			this.HueName.TabIndex = 2;
			this.HueName.Text = "";
			this.HueName.TextChanged += new System.EventHandler(this.HueName_TextChanged);
			// 
			// HueIndex
			// 
			this.HueIndex.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.HueIndex.Location = new System.Drawing.Point(204, 4);
			this.HueIndex.Name = "HueIndex";
			this.HueIndex.Size = new System.Drawing.Size(56, 20);
			this.HueIndex.TabIndex = 3;
			this.HueIndex.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// HueFileName
			// 
			this.HueFileName.Location = new System.Drawing.Point(0, 24);
			this.HueFileName.Name = "HueFileName";
			this.HueFileName.Size = new System.Drawing.Size(260, 20);
			this.HueFileName.TabIndex = 4;
			// 
			// HuePalette
			// 
			this.HuePalette.Color16 = ((short)(0));
			this.HuePalette.Location = new System.Drawing.Point(4, 132);
			this.HuePalette.Name = "HuePalette";
			this.HuePalette.Size = new System.Drawing.Size(440, 272);
			this.HuePalette.TabIndex = 5;
			// 
			// ButtonUpdateColor
			// 
			this.ButtonUpdateColor.Enabled = false;
			this.ButtonUpdateColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.ButtonUpdateColor.Location = new System.Drawing.Point(340, 84);
			this.ButtonUpdateColor.Name = "ButtonUpdateColor";
			this.ButtonUpdateColor.Size = new System.Drawing.Size(104, 40);
			this.ButtonUpdateColor.TabIndex = 6;
			this.ButtonUpdateColor.Text = "Update Color";
			this.ButtonUpdateColor.Click += new System.EventHandler(this.ButtonUpdateColor_Click);
			// 
			// ButtonSpread
			// 
			this.ButtonSpread.Enabled = false;
			this.ButtonSpread.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.ButtonSpread.Location = new System.Drawing.Point(12, 56);
			this.ButtonSpread.Name = "ButtonSpread";
			this.ButtonSpread.TabIndex = 7;
			this.ButtonSpread.Text = "Spread";
			this.ButtonSpread.Click += new System.EventHandler(this.ButtonSpread_Click);
			// 
			// Preview
			// 
			this.Preview.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.Preview.Location = new System.Drawing.Point(448, 196);
			this.Preview.Name = "Preview";
			this.Preview.Size = new System.Drawing.Size(204, 204);
			this.Preview.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
			this.Preview.TabIndex = 8;
			this.Preview.TabStop = false;
			// 
			// NumStatic
			// 
			this.NumStatic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.NumStatic.Location = new System.Drawing.Point(596, 172);
			this.NumStatic.Maximum = new System.Decimal(new int[] {
																	  16382,
																	  0,
																	  0,
																	  0});
			this.NumStatic.Name = "NumStatic";
			this.NumStatic.Size = new System.Drawing.Size(56, 20);
			this.NumStatic.TabIndex = 10;
			this.NumStatic.ValueChanged += new System.EventHandler(this.NumStatic_ValueChanged);
			this.NumStatic.Leave += new System.EventHandler(this.NumStatic_Leave);
			// 
			// button1
			// 
			this.button1.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button1.Location = new System.Drawing.Point(576, 4);
			this.button1.Name = "button1";
			this.button1.TabIndex = 12;
			this.button1.Text = "OK";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// button2
			// 
			this.button2.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button2.Location = new System.Drawing.Point(576, 32);
			this.button2.Name = "button2";
			this.button2.TabIndex = 13;
			this.button2.Text = "Cancel";
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// SatRed
			// 
			this.SatRed.Enabled = false;
			this.SatRed.LargeChange = 1;
			this.SatRed.Location = new System.Drawing.Point(488, 92);
			this.SatRed.Maximum = 32;
			this.SatRed.Minimum = -32;
			this.SatRed.Name = "SatRed";
			this.SatRed.Size = new System.Drawing.Size(168, 45);
			this.SatRed.TabIndex = 14;
			this.SatRed.TickStyle = System.Windows.Forms.TickStyle.None;
			this.SatRed.Scroll += new System.EventHandler(this.SatRed_Scroll);
			// 
			// SatGreen
			// 
			this.SatGreen.Enabled = false;
			this.SatGreen.Location = new System.Drawing.Point(488, 116);
			this.SatGreen.Maximum = 32;
			this.SatGreen.Minimum = -32;
			this.SatGreen.Name = "SatGreen";
			this.SatGreen.Size = new System.Drawing.Size(168, 45);
			this.SatGreen.TabIndex = 15;
			this.SatGreen.TickStyle = System.Windows.Forms.TickStyle.None;
			this.SatGreen.Scroll += new System.EventHandler(this.SatGreen_Scroll);
			// 
			// SatBlue
			// 
			this.SatBlue.Enabled = false;
			this.SatBlue.Location = new System.Drawing.Point(488, 140);
			this.SatBlue.Maximum = 32;
			this.SatBlue.Minimum = -32;
			this.SatBlue.Name = "SatBlue";
			this.SatBlue.Size = new System.Drawing.Size(168, 45);
			this.SatBlue.TabIndex = 16;
			this.SatBlue.TickStyle = System.Windows.Forms.TickStyle.None;
			this.SatBlue.Scroll += new System.EventHandler(this.SatBlue_Scroll);
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(452, 96);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(36, 16);
			this.label3.TabIndex = 17;
			this.label3.Text = "Red";
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(452, 120);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(36, 16);
			this.label4.TabIndex = 18;
			this.label4.Text = "Green";
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(452, 144);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(36, 16);
			this.label5.TabIndex = 19;
			this.label5.Text = "Blue";
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(452, 72);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(204, 16);
			this.label6.TabIndex = 20;
			this.label6.Text = "Change color components";
			// 
			// PreviewList
			// 
			this.PreviewList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.PreviewList.Items.AddRange(new object[] {
															 "Items",
															 "Mobiles",
															 "Gumps"});
			this.PreviewList.Location = new System.Drawing.Point(516, 172);
			this.PreviewList.Name = "PreviewList";
			this.PreviewList.Size = new System.Drawing.Size(76, 21);
			this.PreviewList.TabIndex = 21;
			this.PreviewList.SelectedIndexChanged += new System.EventHandler(this.PreviewList_SelectedIndexChanged);
			// 
			// AnimateCheck
			// 
			this.AnimateCheck.Enabled = false;
			this.AnimateCheck.Location = new System.Drawing.Point(448, 172);
			this.AnimateCheck.Name = "AnimateCheck";
			this.AnimateCheck.Size = new System.Drawing.Size(68, 20);
			this.AnimateCheck.TabIndex = 22;
			this.AnimateCheck.Text = "Animate";
			this.AnimateCheck.CheckedChanged += new System.EventHandler(this.AnimateCheck_CheckedChanged);
			// 
			// Editor
			// 
			this.Controls.Add(this.AnimateCheck);
			this.Controls.Add(this.PreviewList);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.button2);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.NumStatic);
			this.Controls.Add(this.Preview);
			this.Controls.Add(this.ButtonSpread);
			this.Controls.Add(this.ButtonUpdateColor);
			this.Controls.Add(this.HuePalette);
			this.Controls.Add(this.HueFileName);
			this.Controls.Add(this.HueIndex);
			this.Controls.Add(this.HueName);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.Spectrum);
			this.Controls.Add(this.SatBlue);
			this.Controls.Add(this.SatGreen);
			this.Controls.Add(this.SatRed);
			this.Name = "Editor";
			this.Size = new System.Drawing.Size(656, 404);
			((System.ComponentModel.ISupportInitialize)(this.NumStatic)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.SatRed)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.SatGreen)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.SatBlue)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		private int StaticID
		{
			set
			{
				// Write to options
				((HueEditor)FindForm()).Options.StaticID = value;

				UpdatePreview();
			}
			get
			{
				return (int) this.NumStatic.Value;
			}
		}

		private Color GetSelectedColor()
		{
			return HueEntry.ConvertToColor( TheHue.ColorTable[ SelectedIndex ] );
		}

		private void DrawSelection( Graphics g, Brush brush, Pen pen )
		{
			// Get the top left coordinates
			int x = SelectedIndex * 10;
			int y = 0;

			// Set size
			int width = 10;
			int height = 15;

			Rectangle rect = new Rectangle( x, y, width, height );

			if ( SelectedIndex == 31 )
				rect.Width++;

			g.DrawRectangle( pen, rect );
			g.FillRectangle( brush, rect );
		}

		private void ButtonSpread_Click(object sender, System.EventArgs e)
		{
			int start = SelectionStart;
			int end = SelectionEnd;
			
			if ( end < start )
			{
				end = SelectionStart;
				start = SelectionEnd;
			}

			int count = end - start;

			short left = TheHue.ColorTable[ start ];
			short right = TheHue.ColorTable[ end ];

			int sRed = ( ( left >> 10 ) & 0x1F );
			int sGreen = ( ( left >> 5 ) & 0x1F );
			int sBlue = ( left & 0x1F );

			int eRed = ( ( right >> 10 ) & 0x1F );
			int eGreen = ( ( right >> 5 ) & 0x1F );
			int eBlue = ( right & 0x1F );

			float dRed = (float) ( eRed - sRed ) / count;
			float dGreen = (float) ( eGreen - sGreen ) / count;
			float dBlue = (float) ( eBlue - sBlue ) / count;

			for ( int i = 1; i < count; i++ )
			{
				short red = (short) Decimal.Truncate( Math.Round( (decimal)(sRed + i * dRed) ) );
				short green = (short) Decimal.Truncate( Math.Round( (decimal)(sGreen + i * dGreen) ) );
				short blue = (short) Decimal.Truncate( Math.Round( (decimal)(sBlue + i * dBlue) ) );

				short c = (short) ( ( red << 10 ) + ( green << 5 ) + blue );

				TheHue.ColorTable[ start + i ] = c;
				DrawRectangle( start + i );
			}

			Spectrum.Refresh();
			UpdatePreview();
			ResetSaturation();
		}

		private void ButtonUpdateColor_Click(object sender, System.EventArgs e)
		{
			SetColorAt( HuePalette.Color16, Index );
			this.DrawRectangle( Index );
			Spectrum.Refresh();
			this.ResetSaturation();
		}

		private void Spectrum_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			if ( SelectionStart == SelectionEnd )
			{
				DrawStuff( e.Graphics );
			}
			else
			{
				DrawSelection( e.Graphics );
			}
		}

		private void Spectrum_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			ResetSaturation();

			if ( Selecting )
				Selecting = false;

			if ( SelectionStart != SelectionEnd )
			{
				// We have a selection
				SelectionExists = true;
			}
			else
			{
				if ( EditingColor && ( this.GetPointedColor( e.X ) == Index  ) )
				{
					// Exit edit mode
					EditingColor = false;
				}
				else
				{
					// Start edit mode
					EditingColor = true;
					HuePalette.Color16 = TheHue.ColorTable[ SelectionStart ];
				}
			}
		}

		private void Spectrum_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if ( SelectionExists )
				return;

			if ( !Selecting )
			{
				if ( EditingColor )
					return;

				// Calculate the current segment	
				byte ind = GetPointedColor( e.X );

				if ( ind != Index )
					Index = ind;
			}
			else
			{
				if ( e.Button == MouseButtons.Left )
				{
					// There's a selection going on
					byte index = GetPointedColor( e.X );

					if ( ( index < 0 ) || ( index > 31 ) )
						return;

					// Check if we're still in the same area
					if ( SelectionEnd == index )
						return;

					EditingColor = false;

					SelectionEnd = index;

					Spectrum.Refresh();;
				}
			}
		}

		private void Spectrum_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			// Start selecting
			Selecting = true;
			// Remove previous selection
			SelectionExists = false;

			// Either way this will be a new selection
			SelectionStart = GetPointedColor( e.X );
			SelectionEnd = SelectionStart;

			if ( EditingColor && ( Index != SelectionStart ) )
			{
				// Disable Edit Mode
				EditingColor = false;
			}

			Index = SelectionStart;
		}

		private void DrawStuff( Graphics g )
		{
			if ( ( SelectedIndex >= 0 ) && ( SelectedIndex <= 31 ) )
			{
				// Create the color
				Color HueColor = GetSelectedColor();
				Color color;
				int hint = HueColor.R + HueColor.B + HueColor.B;


				if ( hint > 382 )
					// Use black
					color = Color.Black;
				else
					color = Color.White;

				// Make the brush
				SolidBrush brush = new SolidBrush( Color.FromArgb( 90, color ) );

				// Make the pen
				Pen pen = new Pen( new SolidBrush( color ) );

				// Clear the graphics

				DrawSelection( g, brush, pen );
			}
		}

		private void DrawSpectrum()
		{
			for ( int i = 0; i < 32; i++ )
				DrawRectangle( i );
		}

		private void DrawRectangle( int number )
		{
			// Get the top left coordinates
			int x = number * 10;

			for ( int i = x; i < ( x + 10 ); i++ )
				for ( int j = 0; j < 40; j++ )
					TheSpectrum.SetPixel( i, j, HueEntry.ConvertToColor( TheHue.ColorTable[ number ] ) );
		}

		private byte GetPointedColor( int x )
		{
			return (byte) ( x / 10 );
		}

		private void Spectrum_MouseLeave(object sender, System.EventArgs e)
		{
			if ( SelectionExists )
				return;

			Spectrum.Refresh();
		}

		private void DrawSelection( Graphics g )
		{
			// Redraw spectrum

			byte start = 0;
			byte end = 0;

			if ( SelectionStart < SelectionEnd )
			{
				start = SelectionStart;
				end = SelectionEnd;
			}
			else 
			{
				start = SelectionEnd;
				end = SelectionStart;
			}

			// Create the rect
			Rectangle rect = Rectangle.Empty;
			rect.X = start * 10;
			rect.Y = 0;
			rect.Width = ( end - start ) * 10 + 10;
			rect.Height = 15;

			int hint = 0;
			int count = 0;

			// Calculate the best color
			for ( int i = start; i <= end ; i++ )
			{
				Color col = HueEntry.ConvertToColor( TheHue.ColorTable[ i ] );
				int val = (int) ( col.R + col.G + col.B ) / 3;
				hint += val;
				count++;						
			}

			hint = (int) hint / count;

			Color color;

			if ( hint > 127 )
				color = Color.Black;
			else
				color = Color.White;

			// Make brush
			SolidBrush brush = new SolidBrush( Color.FromArgb( 90, color ) );
			// Make pen
			Pen pen = new Pen( new SolidBrush( color ) );

			// Draw the rect
			g.DrawRectangle( pen, rect );

			// Fill it
			g.FillRectangle( brush, rect );
		}

		private void SetColorAt( short color, int index )
		{
			TheHue.ColorTable [ index ] = color;
			UpdatePreview();		
		}

		private void MakeUltimaHue()
		{
			System.IO.MemoryStream theStream = new System.IO.MemoryStream();
			System.IO.BinaryWriter writer = new System.IO.BinaryWriter( theStream, System.Text.Encoding.ASCII );
			TheHue.SaveHue( writer );
			theStream.Seek( 0, System.IO.SeekOrigin.Begin );
			System.IO.BinaryReader reader = new System.IO.BinaryReader( theStream, System.Text.Encoding.ASCII );
			uHue = new Ultima.Hue( 0, reader );
			theStream.Close();
		}

		private void UpdatePreview()
		{
			MakeUltimaHue();

			switch ( pType )
			{
				case PreviewType.Gump:
					try
					{ HuePreview = Ultima.Gumps.GetGump( StaticID ); }
					catch {}
					break;
				case PreviewType.Item:
					try
					{ HuePreview = Ultima.Art.GetStatic( StaticID ); }
					catch { }
					break;
				case PreviewType.Mobile:
					try
					{ HuePreview = Ultima.Animations.GetAnimation( StaticID, 0, 1, 0, false )[ 0 ].Bitmap; }
					catch { }
					break;
				case PreviewType.MobileAnimation:
					try
					{ Animate(); }
					catch { }
					return;
			}

			try
			{ uHue.ApplyTo( HuePreview, false ); }
			catch {}
			Preview.Image = HuePreview;
		}

		private void NumStatic_ValueChanged(object sender, System.EventArgs e)
		{
			if ( !this.Created )
				return;

			StaticID = (int) NumStatic.Value;		
		}

		protected virtual void OnStaticChanged( StaticChangedEventArgs e )
		{
			StaticChanged( this, e );
		}

		private void Animate()
		{
			// Create the frames
			Ultima.Frame[] frames = Ultima.Animations.GetAnimation( this.StaticID, 0, 1, 0, true );

			Animation = new Bitmap[ frames.Length ];

			if ( CurrentFrame >= ( frames.Length - 1 ) )
				CurrentFrame = 0;

			for ( int i = 0; i < frames.Length; i++ )
			{
				Animation[i] = frames[i].Bitmap;
				uHue.ApplyTo( Animation[i], false );
			}

			if ( AnimTimer == null )
			{
				// Init the timer
				AnimTimer = new System.Threading.Timer(
					new TimerCallback( DoAnimation ), null, TimeSpan.Zero, TimeSpan.FromMilliseconds( 1000 / Animation.Length ) );
			}
		}

		private void DoAnimation( object state )
		{
            // Display the Current Frame
			this.Preview.Image = Animation[ CurrentFrame ];

			CurrentFrame++;

			if ( CurrentFrame == Animation.Length )
				CurrentFrame = 0;
		}

		protected virtual void OnEditEnd( EditEndEventArgs e )
		{
			EditEnd( this, e );
		}

		private void NumStatic_Leave(object sender, System.EventArgs e)
		{
			if ( NumStatic.Value < 0 )
				NumStatic.Value = 0;
			if ( NumStatic.Value > 16382 )
				NumStatic.Value = 16382;

			StaticID =(int) NumStatic.Value ;
		}

		private void ResetSaturation()
		{
			SatRed.Value = 0;
			SatGreen.Value = 0;
			SatBlue.Value = 0;
		}

		private byte GetRed( short color )
		{
			return (byte) ( ( color >> 10 ) & 0x1F );
		}

		private byte GetGreen( short color )
		{
			return (byte) (( color >> 5 ) & 0x1F );
		}

		private byte GetBlue( short color )
		{
			return (byte) ( color & 0x1F );
		}

		private short MakeColor( byte red, byte green, byte blue )
		{
			return (short) ( ( red << 10 ) + ( green << 5 ) + blue );
		}

		private short AddComponent( short color, short addition, Component component )
		{
			byte red = GetRed( color );
			byte green = GetGreen( color );
			byte blue = GetBlue( color );

			switch ( component )
			{
				case Component.Red:
					red = ( byte ) Validate( red + addition, 0, 31 );
					break;
				case Component.Green:
					green = ( byte ) Validate( green + addition, 0, 31 );
					break;
				case Component.Blue:
					blue = ( byte ) Validate( blue + addition, 0, 31 );
					break;
			}

			return MakeColor( red, green, blue );

		}

		private int Validate( int number, int lower, int upper )
		{
			if ( number < lower )
				return lower;
			if ( number > upper )
				return upper;
			return number;
		}

		private void SatRed_Scroll(object sender, System.EventArgs e)
		{
			SaturateSelection( Component.Red );
		}

		private void SatGreen_Scroll(object sender, System.EventArgs e)
		{
			SaturateSelection( Component.Green );
		}

		private void SatBlue_Scroll(object sender, System.EventArgs e)
		{
			SaturateSelection( Component.Blue );
		}

		private void SaturateSelection( Component component )
		{
            int start = SelectionStart;
			int end = SelectionEnd;
			if ( end < start )
			{
				start = SelectionEnd;
				end = SelectionStart;
			}

			int addition = 0;

			switch ( component )
			{
				case Component.Red:
					addition = SatRed.Value - RedValue;
					RedValue = SatRed.Value;
					break;
				case Component.Green:
					addition = SatGreen.Value - GreenValue;
					GreenValue = SatGreen.Value;
					break;
				case Component.Blue:
					addition = SatBlue.Value - BlueValue;
					BlueValue = SatBlue.Value;
					break;
			}

			for ( int i = start; i <= end; i++ )
			{
				byte red = GetRed( TheHue.ColorTable[i] );
				byte green = GetGreen( TheHue.ColorTable[i] );
				byte blue = GetBlue( TheHue.ColorTable[i] );

				switch ( component )
				{
					case Component.Red:
						red = (byte) Validate( red + addition, 0, 31 );
						break;
					case Component.Green:
						green = (byte) Validate( green + addition, 0, 31 );
						break;
					case Component.Blue:
						blue = (byte) Validate( blue + addition, 0, 31 );
						break;
				}

				TheHue.ColorTable[i] = MakeColor( red, green, blue );
				DrawRectangle(i);
			}

			UpdatePreview();
			Spectrum.Refresh();
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			EditEndEventArgs ev = new EditEndEventArgs( TheHue, true );
			OnEditEnd( ev );
		}

		private void button2_Click(object sender, System.EventArgs e)
		{
			EditEndEventArgs ev = new EditEndEventArgs( TheHue, false );
			OnEditEnd( ev );
		}

		private void HueName_TextChanged(object sender, System.EventArgs e)
		{
			if ( HueName.Text.Length > 20 )
				HueName.Text = HueName.Text.Substring( 0, 20 );

			string name = HueName.Text;
			if ( name.Length < 20 )
			{
				for ( int i = name.Length; i < 20; i++ )
					name += "\0";
			}

			TheHue.Name = name.ToCharArray();
		}

		private void PreviewList_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if ( !Created )
				return;

			switch ( PreviewList.SelectedIndex )
			{
				case 0:
					pType = PreviewType.Item;
					return;
				case 1:
					if ( this.AnimateCheck.Checked )
						pType = PreviewType.MobileAnimation;
					else
						pType = PreviewType.Mobile;
					return;
				case 2:
					pType = PreviewType.Gump;
					return;					
			}
		}

		private void AnimateCheck_CheckedChanged(object sender, System.EventArgs e)
		{
			if ( !this.Created )
				return;

			if ( AnimateCheck.Checked )
				this.pType = PreviewType.MobileAnimation;
			else
				this.pType = PreviewType.Mobile;

			// Set options
			((HueEditor)FindForm()).Options.AnimCheck = AnimateCheck.Checked;
		}
	}

	public delegate void StaticChangedEventHandler( object sender, StaticChangedEventArgs e );
	public delegate void EditEndEventHandler( object sender, EditEndEventArgs e );

	public class EditEndEventArgs : System.EventArgs
	{
		private bool mApplyChanges;
		public bool ApplyChanges
		{
			get
			{
				return mApplyChanges;
			}
		}

		private HueEntry mTheHue;
		public HueEntry TheHue
		{
			get
			{
				return mTheHue;
			}
		}

		public EditEndEventArgs( HueEntry hue, bool applychanges )
		{
			mTheHue = hue;
			mApplyChanges = applychanges;
		}
	}

	public class StaticChangedEventArgs : System.EventArgs
	{
		private int m_ID;
		public int ID
		{
			get
			{
				return m_ID;
			}
		}
		public StaticChangedEventArgs( int id )
		{
			m_ID = id;
		}
	}
}