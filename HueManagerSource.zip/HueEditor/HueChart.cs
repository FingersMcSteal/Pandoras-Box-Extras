using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace HueEditor
{
	/// <summary>
	/// Summary description for HueChart.
	/// </summary>
	public class HueChart : System.Windows.Forms.Form
	{
		private bool ModifiedFlag = false;
		public bool Modified
		{
			get
			{
				return ModifiedFlag;
			}
			set
			{
				if ( !ModifiedFlag )
				{
					// This is the first time it's modified, append a * at the end of the window text
					Text += " *";
				}

				ModifiedFlag = value;

				// If it's set to false by the framework, remove the *
				if ( !value )
				{
					Text = FileName;
				}
			}
		}

		[DllImport( "User32" )] private static extern short GetKeyState( int nVirtKey );

		private static int VK_SHIFT = 0x10;
		private static int VK_CONTROL = 0x11;
		private static int VK_MENU = 0x12;

		private ArrayList SelectedHues;
		public ArrayList Selection
		{
			get
			{
				return SelectedHues;
			}
		}

		private int MouseX;
		private int MouseY;

		private Bitmap SelectionChart;
		private Bitmap DraggingChart;
		private Bitmap Chart;
		private Bitmap TempBmp;

		private byte GCSteps = 0;
		private short PreviousSelectedColor;
		private short SelectedColor;
		public string FileName;
		private Hues hues;
		private System.Windows.Forms.PictureBox TheImage;
		private System.Windows.Forms.ContextMenu DragDropMenu;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem menuItem2;
		private System.Windows.Forms.MenuItem menuItem3;
		private System.Windows.Forms.MenuItem menuItem4;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		// Events
		public event HueClickedEventHandler HueClicked;
		public event DropSuccesfulEventHandler DropSuccesful;
		public event DragStartEventHandler DragStart;

		public HueChart()
		{
			InitializeComponent();

			FileName = "";
			Text = "New hues mul file";
			SelectedHues = new ArrayList();
			TempBmp = new Bitmap( 450, 300 );

			hues = new Hues();

			DrawHues();

			TheImage.AllowDrop = true;

			SelectedHues.Add( (short) 1 );
			DrawSelectionChart();
			SelectedHues.Clear();
			TheImage.Image = Chart;
			SelectionChart = (Bitmap) Chart.Clone();
		}

		public HueChart( string fileName )
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			FileName = fileName;
			Text = FileName;
			SelectedHues = new ArrayList();
			TempBmp = new Bitmap( 450, 300 );

			// Load hues
			hues = new Hues( FileName, true );

			// Draw the hues
			DrawHues();

			// Allow dropping on the chart
			TheImage.AllowDrop = true;

			SelectedHues.Add( (short) 1 );
			DrawSelectionChart();
			SelectedHues.Clear();
			TheImage.Image = Chart;
			SelectionChart = (Bitmap) Chart.Clone();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(HueChart));
			this.TheImage = new System.Windows.Forms.PictureBox();
			this.DragDropMenu = new System.Windows.Forms.ContextMenu();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.menuItem2 = new System.Windows.Forms.MenuItem();
			this.menuItem3 = new System.Windows.Forms.MenuItem();
			this.menuItem4 = new System.Windows.Forms.MenuItem();
			this.SuspendLayout();
			// 
			// TheImage
			// 
			this.TheImage.Dock = System.Windows.Forms.DockStyle.Fill;
			this.TheImage.Location = new System.Drawing.Point(0, 0);
			this.TheImage.Name = "TheImage";
			this.TheImage.Size = new System.Drawing.Size(450, 300);
			this.TheImage.TabIndex = 0;
			this.TheImage.TabStop = false;
			this.TheImage.DragEnter += new System.Windows.Forms.DragEventHandler(this.TheImage_DragEnter);
			this.TheImage.DragLeave += new System.EventHandler(this.TheImage_DragLeave);
			this.TheImage.DragDrop += new System.Windows.Forms.DragEventHandler(this.TheImage_DragDrop);
			this.TheImage.DragOver += new System.Windows.Forms.DragEventHandler(this.TheImage_DragOver);
			this.TheImage.MouseMove += new System.Windows.Forms.MouseEventHandler(this.TheImage_MouseMove);
			this.TheImage.MouseDown += new System.Windows.Forms.MouseEventHandler(this.TheImage_MouseDown);
			// 
			// DragDropMenu
			// 
			this.DragDropMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						 this.menuItem1,
																						 this.menuItem2,
																						 this.menuItem3,
																						 this.menuItem4});
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 0;
			this.menuItem1.Text = "Copy ( Doesn\'t delete original selection )";
			this.menuItem1.Click += new System.EventHandler(this.menuItem1_Click);
			// 
			// menuItem2
			// 
			this.menuItem2.Index = 1;
			this.menuItem2.Text = "Move ( Deletes original selection )";
			this.menuItem2.Click += new System.EventHandler(this.menuItem2_Click);
			// 
			// menuItem3
			// 
			this.menuItem3.Index = 2;
			this.menuItem3.Text = "-";
			// 
			// menuItem4
			// 
			this.menuItem4.Index = 3;
			this.menuItem4.Text = "Abort";
			// 
			// HueChart
			// 
			this.AllowDrop = true;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(450, 300);
			this.Controls.Add(this.TheImage);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.HelpButton = true;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.Name = "HueChart";
			this.Closing += new System.ComponentModel.CancelEventHandler(this.HueChart_Closing);
			this.ResumeLayout(false);

		}
		#endregion

		private void DrawHues()
		{
			Chart = new Bitmap( 450, 300 );

			int Brightness = 28;
			int Index = 0;

			foreach ( HueGroup group in hues.TheHues )
			{
				foreach ( HueEntry entry in group.Entries )
				{
					// Draw the box for the hue
					DrawBox( Chart, entry.ColorTable[ Brightness ], Index );
					Index++;
				}
			}

			// Display the chart
			TheImage.Image = Chart;
		}

		private void DrawBox( Bitmap bmp, short Color16, int Index )
		{
			// Calculate the row and column (zero based)
			int column = (int) ( Index / 60 );
			int row = Index % 60;

			// Get the color
			Color color = HueEntry.ConvertToColor( Color16 );

			// Find the top left corner of the box
			short x = (short) ( column * 9 );
			short y = (short) ( row * 5 );

			// Color
			for ( short iX = 0; iX < 9; iX++ )
				for ( short iY = 0; iY < 5; iY ++ )
					bmp.SetPixel( x + iX, y + iY, color );
		}

		protected virtual void OnHueClicked( HueClickedEventArgs e )
		{
			// Invoke the delegate
			HueClicked( this, e );
		}

		protected virtual void OnDragStart( System.Windows.Forms.DragEventArgs e )
		{
			DragStart( this, e );
		}

		protected virtual void OnDropSuccesful( DropSuccesfulEventArgs e )
		{
			DropSuccesful( this, e );
		}

		private short GetHueIndex( int x, int y )
		{
			int column = (int) ( x / 9 );
			int row = (int) ( y / 5 );
			return (short) ( column * 60 + row + 1 );
		}

		private void DrawSelectionChart()
		{
			if ( SelectedHues.Count == 0 )
			{
				TheImage.Image = Chart;
				return;
			}

			SelectedHues.Sort();
			SelectionChart = DrawSelection( Chart, SelectedHues, Color.White );
			TheImage.Image = SelectionChart;
		}

		private void TheImage_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			// Get the hue index ( zero based )
			SelectedColor = GetHueIndex( e.X, e.Y );

			if ( e.Button == MouseButtons.Right )
			{
				// If there's no color selected, add the current one
				if ( SelectedHues.Count == 0 )
				{
					SelectedHues.Add( SelectedColor );
					DrawSelectionChart();
				}

				// If the click is out of the selection do nothing
				if ( !SelectedHues.Contains( SelectedColor ) )
					return;

				// DRAGGING
				HuesDragData dData = new HuesDragData( SelectedHues, SelectedColor );
				this.DoDragDrop( dData, DragDropEffects.All );

				// Send notification to parent
				DataObject dobj = new DataObject( dData );
				System.Windows.Forms.DragEventArgs de = new DragEventArgs( dobj, 0, 0, 0, DragDropEffects.All, DragDropEffects.All );
				this.OnDragStart( de );				
				return;
			}

			// Get the right hue
			int GroupNumber = (int) ( (SelectedColor - 1) / 8 );
			HueGroup Group = (HueGroup) hues.TheHues[ GroupNumber ];

			int HueNumber = (SelectedColor-1) % 8;
			HueEntry hue = Group.Entries[ HueNumber ];

			// Fire the event
			HueClickedEventArgs dev = new HueClickedEventArgs( hue, SelectedColor );
			OnHueClicked( dev );

			// Handle selection of hues

			if ( ! ( ShiftPressed() || ControlPressed() ) )
			{
				if ( ( SelectedHues.Count == 1 ) && ( SelectedHues.Contains( SelectedColor ) ) )
				{
					SelectedHues.Clear();
					DrawSelectionChart();
					return;
				}
				// No modifier keys pressed. Clear selection and add current item
				SelectedHues.Clear();
				SelectedHues.Add( SelectedColor );
				PreviousSelectedColor = SelectedColor;
				DrawSelectionChart();
				return;
			}

			if ( SelectedHues.Contains( SelectedColor ) )
			{
				// Clicking the same just deselects it
				SelectedHues.Remove( SelectedColor );
				
				if ( ShiftPressed() )
				{
					// Go down
					if ( SelectedHues.Contains( (short) (SelectedColor + 1) ) )
					{
						for ( short i = (short) ( SelectedColor + 1 ); i <= PreviousSelectedColor; i++ )
						{
							if ( SelectedHues.Contains( i ) )
								SelectedHues.Remove( i );
							else
								break;
						}
					}
				}
				PreviousSelectedColor = (short) ( SelectedColor - 1 );
				DrawSelectionChart();
				return;
			}

			if (  ControlPressed() )
			{
				// Add a single item to the list
				SelectedHues.Add( SelectedColor );
				PreviousSelectedColor = SelectedColor;
				DrawSelectionChart();
				return;
			}

			if ( ShiftPressed() )
			{
				// Add a selection of items
				if ( PreviousSelectedColor < SelectedColor )
				{
					// Moving backwards
					for ( short i = SelectedColor; i > PreviousSelectedColor; i-- )
						if ( !SelectedHues.Contains( i ) )
							SelectedHues.Add( i );
				}
				if ( PreviousSelectedColor > SelectedColor )
				{
					// Moving forward
					for ( short i = SelectedColor; i < PreviousSelectedColor; i++ )
						if ( !SelectedHues.Contains( i ) ) // Avoid duplicates
							SelectedHues.Add( i );
				}

				PreviousSelectedColor = SelectedColor;
				DrawSelectionChart();
				return;
			}
		}

		public void EndDrag()
		{
			if ( SelectedHues.Count > 0 )
				TheImage.Image = SelectionChart;
			else
				TheImage.Image = Chart;
		}

		private Bitmap DrawSelection(Bitmap oldImg, ArrayList list, Color color)
		{
			TempBmp = (Bitmap) oldImg.Clone();

			// Performe garbage collection once every 5 steps
			if ( GCSteps == 5 )
			{
				GC.Collect();
				GCSteps = 0;
			}
			else
				GCSteps++;

			// Sort the selected hues
			list.Sort();

			bool Range = false;
			short First = (short) list[0];
			short Last = First;

			foreach ( short s in list )
			{
				if ( First == s )
					continue;

				if ( s == ( Last + 1 ) )
				{
					Range = true;
					Last = s;
					continue;
				}

				if ( Range )
					DrawSelectionBox( TempBmp, (short) ( First - 1 ), (short) ( Last - 1 ) , color );
				else
					DrawSelectionBox( TempBmp, (short) ( First - 1 ) , color );

				Range = false;
				First = s;
				Last = s;				
			}

			if ( Range )
				DrawSelectionBox( TempBmp, (short) ( First - 1 ), (short) (Last - 1 ), color);
			else
				DrawSelectionBox( TempBmp, (short) ( First - 1 ), color );

			return TempBmp;
		}

		private void DrawSelectionBox( Bitmap img, short first, short last, Color color )
		{
			int c1 = (int) ( first / 60 );
			int c2 = (int) ( last / 60 );
			int r1 = first % 60;
			int r2 = last % 60;

			if ( c2 == c1 )
			{
				// Draw a long box
				short x = (short) (c1 * 9 );
				short y1 = (short) ( r1 * 5 );
				short y2 = (short) ( ( r2 * 5 ) + 4 );

				for ( short i = 0; i < 8; i++ )
				{
					img.SetPixel( x + i, y1, color );
					img.SetPixel( x + i, y2, color );
				}

				for ( short i = y1; i <= y2; i++ )
				{
					img.SetPixel( x, i, color );
					img.SetPixel( x + 8, i, color );
				}
			}

			if ( c2 > c1 )
			{
				// Get the two points first
				short x1 = ( short ) ( c1 * 9 );
				short x2 = ( short ) ( c2 * 9 );
				short y1 = ( short ) ( r1 * 5 );
				short y2 = ( short ) ( r2 * 5 );

				short TopX1 = (short) ( x1 + 9 ); // Can't be invalid
				short TopX2 = (short) ( x2 + 8 );

				// Draw the top segment
				for ( short i = TopX1; i <= TopX2; i++ )
					img.SetPixel( i, 0, color );

				short BottomX1 = x1;
				short BottomX2 = (short) ( x2 - 1 ); // Can't be invalid

				// Draw the bottom segment
				for ( short i = BottomX1; i <= BottomX2; i++ )
					img.SetPixel( i, 299, color );

				// Draw left horizontal segment, height: y1
				for ( short i = BottomX1; i <= TopX1; i++ )
				{
					if ( ( c2 == ( c1+1 ) ) && ( i == TopX1 ) )
						break;
					img.SetPixel( i, y1, color );
				}

				// Draw right horizontal segment, height: y2 + 5;
				y2 += 4;
				for ( short i = BottomX2; i <= TopX2; i++ )
				{
					if ( ( c2 == ( c1+1) ) && ( i == BottomX2 ) )
						continue;
					img.SetPixel( i, y2, color );
				}

				// Draw left segment
				for ( short i = y1; i <= 299; i++ )
					img.SetPixel( BottomX1, i, color );

				short my = 0;

				if ( c2 == ( c1+1 ) )
					my = Math.Min( y1, y2 );
				else
					my = y1;

				// Draw top left segment
				for ( short i = 0; i <= my; i++ )
					img.SetPixel( TopX1, i, color );

				// Draw right segment
				for ( short i = 0; i <= y2; i++ )
					img.SetPixel( TopX2, i, color );

				if ( c2 == ( c1+1 ) )
					my = Math.Max( y1, y2 );
				else
					my = y2;

				// Draw bottom right segment
				for ( short i = my; i <= 299; i++ )
					img.SetPixel( BottomX2, i, color );				
			}			
		}

		private void DrawSelectionBox( Bitmap img, short index, Color color )
		{
			// Draw a single box around a single hue
			// Calculate the row and column (zero based)
			int column = (int) ( index / 60 );
			int row = index % 60;

			// Find the top left corner of the box
			short x = (short) ( column * 9 );
			short y = (short) ( row * 5 );

			// Draw the box
			for ( short iX = 0; iX < 9; iX++ )
			{
				img.SetPixel( x + iX, y, color );
				img.SetPixel( x + iX, y + 5 - 1, color );
			}
			for ( short iY = 0; iY < 5; iY ++ )
			{
				img.SetPixel( x, y + iY, color );
				img.SetPixel( x + 9 - 1, y + iY, color );
			}
		}

		private short GetGroupNumber( short index )
		{
			return (short) ( ( index - 1 ) / 8 );
		}

		private short GetEntryNumber( short index )
		{
			return (short) (  ( index - 1 ) % 8 );
		}

		private HueEntry GetHue( short index )
		{
			HueGroup group = (HueGroup) hues.TheHues[ GetGroupNumber( index ) ];
			return group.Entries[ GetEntryNumber( index ) ];
		}

		public void RemoveHueAt( short index )
		{
			short groupNumber = GetGroupNumber( index );
			short hueNumber = GetEntryNumber( index );

			( (HueEntry) ( (HueGroup ) hues.TheHues[ groupNumber ] ).Entries[ hueNumber ] ).Delete();

			// Redraw modified hue
			DrawBox( Chart, ( (HueEntry) ( (HueGroup ) hues.TheHues[ groupNumber ] ).Entries[ hueNumber ] ).ColorTable[ 28 ], index - 1 );
			TheImage.Image = Chart;

			// Select the hue
			HueClickedEventArgs e = new HueClickedEventArgs( GetHue( index ), index );	
			OnHueClicked( e );
		}

		private bool ShiftPressed()
		{
			short shift = GetKeyState( VK_SHIFT );
			if ( shift < -100 )
				return true;
			else
				return false;			
		}

		private bool ControlPressed()
		{
			short control = GetKeyState( VK_CONTROL );
			if ( control < -100 )
				return true;
			else
				return false;
		}

		private bool AltPressed()
		{
			short alt = GetKeyState( VK_MENU );
			if ( alt < -100 )
				return true;
			else
				return false;
		}


		private void TheImage_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if ( e.Button == MouseButtons.Left )
			{
				// If Alt is pressed, don't select
				if ( AltPressed() )
					return;

				// Get the hue index ( zero based )
				int column = (int) ( e.X / 9 );
				int row = (int) ( e.Y / 5 );
				short selHue = (short) ( column * 60 + row + 1 );

				if ( ( column >= 0 ) && ( column <= 49 ) && ( row >= 0 ) && ( row <= 59 ) )
				{
					if ( !SelectedHues.Contains( selHue ) )
					{
						SelectedHues.Add( selHue );
						PreviousSelectedColor = selHue;
						DrawSelectionChart();
					}
				}
			}
		}

		public void PreviewDrop( ArrayList selection, short index )
		{
			DraggingChart = null;

			if ( SelectedHues.Count == 0 )
				DraggingChart = Chart;
			else
				DraggingChart = SelectionChart;

			short current = GetHueIndex( MouseX, MouseY );
			short delta = (short) (current - index);

			ArrayList DrawList = new ArrayList();

			selection.Sort();

			// Make sure it doesn't go out of the screen
			short diff = (short) ( (short)selection[0] + delta - 1);

			if ( diff < 0 )
				delta -= diff;

			diff = (short) ( (short)selection[ selection.Count - 1] + delta );
			if ( diff > 3000 )
				delta -= (short) ( diff - 3000 );

			foreach ( short s in selection )
				DrawList.Add( (short) ( s + delta ) );

			TheImage.Image = DrawSelection( SelectionChart, DrawList, Color.Blue );
		}

		public void ClearTargetDrop()
		{
			if ( SelectedHues.Count > 0 )
				DrawSelectionChart();
			else
				TheImage.Image = Chart;
		}

		private void TheImage_DragEnter(object sender, System.Windows.Forms.DragEventArgs e)
		{
			if ( e.Data.GetData(typeof(HuesDragData)) is HuesDragData )
			{
				ClearTargetDrop();
				// Do the real dragging!
				e.Effect = DragDropEffects.All;
				this.Select();
			}
		}

		private void TheImage_DragOver(object sender, System.Windows.Forms.DragEventArgs e)
		{
			HuesDragData dData = (HuesDragData) e.Data.GetData( typeof(HuesDragData) );
			Point p = this.PointToClient( new Point( e.X, e.Y ) );
			MouseX = p.X;
			MouseY = p.Y;
			this.PreviewDrop( dData.HuesList, dData.SelectionCenter );
		}

		private void TheImage_DragLeave(object sender, System.EventArgs e)
		{
			ClearTargetDrop();
		}

		public void ClearSelection()
		{
			this.SelectedHues.Clear();
			SelectionChart = (Bitmap) Chart.Clone();
			this.TheImage.Image = Chart;
		}

		private void TheImage_DragDrop(object sender, System.Windows.Forms.DragEventArgs e)
		{
			Point p = this.PointToClient( new Point( e.X, e.Y ) );
			this.DragDropMenu.Show( this, p );
		}

		private void menuItem1_Click(object sender, System.EventArgs e)
		{
			// Copy hues, doesn't affect the original
			this.OnDropSuccesful( new DropSuccesfulEventArgs( false ) );
		}

		public void Save( string filename )
		{
            this.hues.SaveHues( filename );
			this.FileName = filename;
		}

		public ArrayList GetHues( ArrayList Indexes )
		{
			ArrayList ActualHues = new ArrayList();

			Indexes.Sort();

			foreach ( short s in Indexes )
				ActualHues.Add( GetHue( s ) );

			return ActualHues;
		}

		public void CopyHues( ArrayList newHues, ArrayList Indexes, short selectionCenter )
		{
			short index = this.GetHueIndex( MouseX, MouseY );

			// Make sure it doesn't go out of the screen
			short delta = (short) (index - selectionCenter);
			short diff = (short) ( (short)Indexes[0] + delta - 1);

			if ( diff < 0 )
				delta -= diff;

			diff = (short) ( (short)Indexes[ Indexes.Count - 1] + delta );
			if ( diff > 3000 )
				delta -= (short) ( diff - 3000 );

			ArrayList IndexList = new ArrayList();

			foreach ( short s in Indexes )
				IndexList.Add( (short) ( s + delta ) );

			// Now we have the real positions where to drop the hues

			for ( int i = 0; i < newHues.Count; i++ )
				this.hues.SetHueAt( (HueEntry) newHues[i], (short) IndexList[i] );

			// Update the display
			UpdateDisplay();
		}

		public void DeleteHues( ArrayList Indexes )
		{
			foreach ( short s in Indexes )
				RemoveHueAt( s );
		}

		private void UpdateDisplay()
		{
			DrawHues();
			SelectionChart = (Bitmap) Chart.Clone();
			DrawSelectionChart();
		}

		private void menuItem2_Click(object sender, System.EventArgs e)
		{
			//  Move hues
			this.OnDropSuccesful( new DropSuccesfulEventArgs( true ) );
		}

		public void DeleteSelection()
		{
			foreach( short s in SelectedHues )
			{
				short groupNumber = GetGroupNumber( s );
				short hueNumber = GetEntryNumber( s );

				( (HueEntry) ( (HueGroup ) hues.TheHues[ groupNumber ] ).Entries[ hueNumber ] ).Delete();
			}

			this.SelectedHues.Clear();

			this.UpdateDisplay();

			this.Modified = true;
		}

		private void RedrawHue( short index )
		{
			DrawBox( Chart, this.GetHue( index ).ColorTable[28], index - 1 );
			DrawBox( SelectionChart, this.GetHue( index ).ColorTable[28], index - 1 );
			if ( DraggingChart != null )
				DrawBox( DraggingChart, this.GetHue( index ).ColorTable[28], index - 1 );
			if ( TempBmp != null )
				DrawBox( TempBmp, this.GetHue( index ).ColorTable[28], index - 1 );

			if ( this.Selection.Count > 0 )
				TheImage.Image = SelectionChart;
			else
				TheImage.Image = Chart;

			// Fire event to update display
			HueClickedEventArgs ev = new HueClickedEventArgs( GetHue( index ), index );
		}

		public void SetHueAt( HueEntry hue, short index )
		{
			this.hues.SetHueAt( hue, index );
			RedrawHue( index );
			this.Modified = true;
		}

		private void HueChart_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			if ( this.Modified )
			{
				if ( MessageBox.Show(this,
					string.Format("The file {0} has been modified and not saved. Would you like to save it before exiting?", this.FileName),
					"Save file?",
					MessageBoxButtons.YesNo,
					MessageBoxIcon.Question )
					== DialogResult.Yes )
				{
					System.Windows.Forms.SaveFileDialog SaveFile = new SaveFileDialog();
					SaveFile.Filter = "Mul files (*.mul)|*.mul";
					SaveFile.FileName = this.FileName;

					if ( SaveFile.ShowDialog() == DialogResult.OK )
					{
						this.Save( SaveFile.FileName );
					}
				}
			}

			this.ModifiedFlag = false;
		}
	}

	// Delegates
	public delegate void HueClickedEventHandler( object sender, HueClickedEventArgs e );
	public delegate void DropSuccesfulEventHandler( object sender, DropSuccesfulEventArgs e );
	public delegate void DragStartEventHandler( object sender, System.Windows.Forms.DragEventArgs e );

	public class DropSuccesfulEventArgs : System.EventArgs
	{
		public bool RemoveOriginal
		{
			get
			{
				return removeOriginal;
			}
		}
		private bool removeOriginal;

		public DropSuccesfulEventArgs( bool removeoriginal )
		{
			removeOriginal = removeoriginal;
		}		
	}

	public class HueClickedEventArgs : System.EventArgs
	{
		/// <summary>
		/// The Hue that has been selected
		/// </summary>
		public HueEntry SelectedHue
		{
			get
			{
				return hue;
			}
		}

		public short Index
		{
			get
			{
				return index;
			}
		}
		
		private HueEntry hue;
		private short index;

		public HueClickedEventArgs( HueEntry selectedHue, short hueIndex )
		{
			hue = selectedHue;
			index = hueIndex;
		}
	}
}