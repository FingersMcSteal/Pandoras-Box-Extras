using System;
using System.Collections;
using System.IO;
using System.Drawing;

namespace HueEditor
{
	/// <summary>
	/// A single hue entry
	/// </summary>
	public class HueEntry : ICloneable
	{
		public short[] ColorTable;
		public short TableStart;
		public short TableEnd;
		public char[] Name;

		public HueEntry()
		{
			ColorTable = new short[32];
			Name = new char[20];
		}

		public object Clone()
		{
			HueEntry he = new HueEntry();
			for ( int i = 0; i < this.ColorTable.Length; i++ )
				he.ColorTable[i] = this.ColorTable[i];
			he.TableEnd = this.TableEnd;
			he.TableStart = this.TableStart;
			for ( int i = 0; i < this.Name.Length; i++ )
				he.Name[i] = this.Name[i];
			return he;
		}

		public void Delete()
		{
			ColorTable = new short[32];
			TableStart = 0;
			TableEnd = 0;
			Name = new char[20];
		}

		public void SaveHue( BinaryWriter writer )
		{
			// Write the color table
			for ( int i = 0; i < 32; i++ )
				writer.Write( ColorTable[i] );
			// Write start
			writer.Write( TableStart );
			writer.Write( TableEnd );
			// Write the name
			for ( int i = 0; i < 20; i++ )
				writer.Write( Name[i] );
		}

		public void ReadHue(BinaryReader reader)
		{
			// Read the color table
			for ( int i = 0; i < 32; i++ )
				ColorTable[i] = reader.ReadInt16();
			// Read the start
			TableStart = reader.ReadInt16();
			// Read the end
			TableEnd = reader.ReadInt16();
			// Read the name
			for ( int i = 0; i < 20; i++ )
				Name[i] = reader.ReadChar();
		}

		public static short ConvertToColor16( Color color )
		{
			
			int Red = color.R;
			int Green = color.G;
			int Blue = color.B;

			int Color16 = Blue;
			Color16 += ( Green << 5 );
			Color16 += ( Red << 10 );

			return (short) ( Color16 / 8 );
		}

		public static Color ConvertToColor(short Color16)
		{
			/* int Color32 = ( (((Color16 >> 10) & 0x1F) * 0xFF / 0x1F) |
				((((Color16 >> 5) & 0x1F) * 0xFF / 0x1F) << 8) |
				((( Color16 & 0x1F) * 0xFF / 0x1F) << 16));*/

			int Red = ( ( Color16 >> 10 ) & 0x1F ) * 8;
			int Green = ( ( Color16 >> 5 ) & 0x1F ) * 8;
			int Blue = ( Color16 & 0x1F ) * 8;

			Color color = Color.FromArgb( Red, Green, Blue);


			return color;

			// return Color.FromArgb( Color32 );
		}
	}

	/// <summary>
	///  A group of 8 hues
	/// </summary>
	public class HueGroup
	{
		public int Header;
		public HueEntry[] Entries;

		public HueGroup()
		{
			Entries = new HueEntry[8];
		}
		
		/// <summary>
		/// Reads a HueGroup from a reader
		/// </summary>
		/// <param name="reader">The binary reader used to read the group</param>
		public void ReadHueGroup(BinaryReader reader)
		{
			// Read the header
			Header = reader.ReadInt32();

			for ( int i = 0; i < 8; i++ )
			{
				Entries[i] = new HueEntry();
				Entries[i].ReadHue( reader );
			}		
		}

		public void SaveHueGroup( BinaryWriter writer )
		{
			// Write the header
			writer.Write( Header );

			// Write the hues
			foreach ( HueEntry hue in Entries )
				hue.SaveHue( writer );
		}
	}

	/// <summary>
	/// This is the collection of hues
	/// </summary>
	public class Hues
	{
		/// <summary>
		/// The path to the hues.mul file
		/// </summary>
		public string Path = "";
		/// <summary>
		/// The list of hues
		/// </summary>
		public ArrayList TheHues;
		/// <summary>
		/// Creates a Hues object
		/// </summary>
		/// <param name="path">The path to hues.mul</param>
		public Hues(string path)
		{
			Path = path + "\\hues.mul" ;
			TheHues = new ArrayList();
		}

		/// <summary>
		/// Creates a Hues object
		/// </summary>
		/// <param name="FileName">The filename of the mul file</param>
		/// <param name="LoadHues">Specifies if the Hues should be loaded in the constructor</param>
		public Hues(string FileName, bool loadHues )
		{
			Path = FileName;
			TheHues = new ArrayList();

			if ( loadHues )
				LoadHues();
		}

		/// <summary>
		/// Create a blank Hues file
		/// </summary>
		public Hues()
		{
			TheHues = new ArrayList();
			for ( int g = 0; g < 375; g++ )
			{
				HueGroup group = new HueGroup();
				for ( int e = 0; e < 8; e++ )
				{
					group.Entries[e] = new HueEntry();
				}
				TheHues.Add( group );
			}				
		}

		public void SaveHues( string FileName )
		{
			FileStream theStream = new FileStream( FileName, FileMode.Create );
			BinaryWriter writer = new BinaryWriter( theStream, System.Text.Encoding.ASCII );

			foreach ( HueGroup group in this.TheHues )
				group.SaveHueGroup( writer );

			writer.Close();
		}

		/// <summary>
		/// Load the hues from the hues.mul file
		/// </summary>
		/// <returns>True if succesful</returns>
		public bool LoadHues()
		{
			// Check if file exists first
			if ( !System.IO.File.Exists( Path ) )
				return false;

			// Clear the list
			TheHues.Clear();

			// Open the file in read only mode and create the binary reader
			FileStream theStream;
			theStream = new FileStream( Path, FileMode.Open, FileAccess.Read );
			BinaryReader reader = new BinaryReader(theStream, System.Text.Encoding.ASCII);

			int i = 0;

			try
			{
				while ( true )
				{
					HueGroup group = new HueGroup();
					group.ReadHueGroup( reader );
					TheHues.Add( group );
					i++;
				}
			}
			catch ( Exception )
			{
				// End of file has been reached. Do nothing
			}
			reader.Close();
			return true;
		}

		public void SetHueAt( HueEntry hue, short Index )
		{
			short group = (short) ( ( Index - 1 ) / 8 );
			short num = (short) (  ( Index - 1 ) % 8 );

			((HueGroup) this.TheHues[ group ] ).Entries[num] = (HueEntry) hue.Clone();
		}
	}
}