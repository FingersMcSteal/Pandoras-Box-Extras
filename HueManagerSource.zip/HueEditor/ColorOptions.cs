using System;

namespace HueEditor
{
	[Serializable]
	public class ColorOptions
	{

		public bool AnimCheck = false;
		public Editor.PreviewType pType = Editor.PreviewType.Item;
		public string[] RecentFiles;
		public int StaticID;


		public ColorOptions()
		{
			RecentFiles = new string[ 4 ];
		}

		public void AddRecentFile( string filename )
		{
			int existing = -1;

			for( int i = 0; i < 4; i++ )
			{
				if ( RecentFiles[i] == filename )
						existing = i;
			}

			if ( existing == -1 )
			{
				// This one doesn't exist... shift and then add
				for ( int i = 3; i > 0; i-- )
					RecentFiles[ i ] = RecentFiles[ i - 1 ];
				RecentFiles[0] = filename;
			}
			else
			{
				if ( existing == 0 )
					return;

				// This one already exists... move it to the top and shift the others
				for ( int i = existing; i > 0; i-- )
					RecentFiles[ i ] = RecentFiles[ i - 1 ];
				RecentFiles[0] = filename;
			}
		}

		public void DeleteRecent( int index )
		{
			for ( int i = index; i < 3; i++ )
				RecentFiles[ i ] = RecentFiles [ i + 1 ];

			RecentFiles[3] = null;
		}
	}
}