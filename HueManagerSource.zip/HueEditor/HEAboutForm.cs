using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace HueEditor
{
	/// <summary>
	/// Summary description for HEAboutForm.
	/// </summary>
	public class HEAboutForm : System.Windows.Forms.Form
	{
		private DateTime tracktime;

		private static string License =
			"This software is provided as is without warranties of any kind. In no event shall the author be liable for any direct, special, indirect or consequential damages whatsoever resulting from loss of use of data or profits, whether in an action of contract, negligence or other tortious conduct, arising out of or in connection with the use or performance of this software.";

		private System.Windows.Forms.Label LabelVersion;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.LinkLabel linkLabel1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox LicenseText;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Label label2;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public HEAboutForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			LabelVersion.Text = "Version " + this.ProductVersion;

			LicenseText.Text = License;

			tracktime = System.DateTime.Now;

			Ultima.Client.Handle;

			NativeWindow nw = NativeWindow.FromHandle( Ultima.Client.Handle );
			nw.Text;
			
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(HEAboutForm));
			this.LabelVersion = new System.Windows.Forms.Label();
			this.panel1 = new System.Windows.Forms.Panel();
			this.label1 = new System.Windows.Forms.Label();
			this.LicenseText = new System.Windows.Forms.TextBox();
			this.button1 = new System.Windows.Forms.Button();
			this.linkLabel1 = new System.Windows.Forms.LinkLabel();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.label2 = new System.Windows.Forms.Label();
			this.panel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// LabelVersion
			// 
			this.LabelVersion.Location = new System.Drawing.Point(232, 8);
			this.LabelVersion.Name = "LabelVersion";
			this.LabelVersion.Size = new System.Drawing.Size(208, 23);
			this.LabelVersion.TabIndex = 0;
			this.LabelVersion.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.White;
			this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel1.Controls.Add(this.label1);
			this.panel1.Controls.Add(this.LicenseText);
			this.panel1.Controls.Add(this.LabelVersion);
			this.panel1.Location = new System.Drawing.Point(8, 8);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(448, 152);
			this.panel1.TabIndex = 1;
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.MidnightBlue;
			this.label1.Location = new System.Drawing.Point(8, 8);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(208, 23);
			this.label1.TabIndex = 2;
			this.label1.Text = "HUE MANAGER";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.label1.MouseHover += new System.EventHandler(this.label1_MouseMove);
			this.label1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.label1_MouseMove);
			// 
			// LicenseText
			// 
			this.LicenseText.BackColor = System.Drawing.Color.White;
			this.LicenseText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.LicenseText.Enabled = false;
			this.LicenseText.Location = new System.Drawing.Point(8, 40);
			this.LicenseText.Multiline = true;
			this.LicenseText.Name = "LicenseText";
			this.LicenseText.Size = new System.Drawing.Size(432, 104);
			this.LicenseText.TabIndex = 1;
			this.LicenseText.Text = "";
			// 
			// button1
			// 
			this.button1.BackColor = System.Drawing.Color.White;
			this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.button1.Location = new System.Drawing.Point(392, 256);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(64, 23);
			this.button1.TabIndex = 2;
			this.button1.Text = "Close";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// linkLabel1
			// 
			this.linkLabel1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.linkLabel1.ForeColor = System.Drawing.Color.MidnightBlue;
			this.linkLabel1.LinkColor = System.Drawing.Color.MidnightBlue;
			this.linkLabel1.Location = new System.Drawing.Point(224, 208);
			this.linkLabel1.Name = "linkLabel1";
			this.linkLabel1.Size = new System.Drawing.Size(216, 23);
			this.linkLabel1.TabIndex = 3;
			this.linkLabel1.TabStop = true;
			this.linkLabel1.Text = "http://www.openthebox.tk";
			this.linkLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.linkLabel1.VisitedLinkColor = System.Drawing.Color.Black;
			this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
			// 
			// pictureBox1
			// 
			this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(8, 168);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(216, 112);
			this.pictureBox1.TabIndex = 4;
			this.pictureBox1.TabStop = false;
			this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(224, 176);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(232, 32);
			this.label2.TabIndex = 5;
			this.label2.Text = "For information, updates and support, please visit The Box.";
			// 
			// HEAboutForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.BackColor = System.Drawing.Color.White;
			this.ClientSize = new System.Drawing.Size(464, 286);
			this.ControlBox = false;
			this.Controls.Add(this.label2);
			this.Controls.Add(this.pictureBox1);
			this.Controls.Add(this.linkLabel1);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.panel1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.Name = "HEAboutForm";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.TopMost = true;
			this.panel1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void linkLabel1_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
		{
			System.Diagnostics.Process.Start( "http://www.openthebox.tk/" );
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void pictureBox1_Click(object sender, System.EventArgs e)
		{
			System.Diagnostics.Process.Start( "http://www.openthebox.tk/" );
		}

		private void label1_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			label1_MouseMove( sender, new EventArgs() );			
		}

		private void label1_MouseMove(object sender, System.EventArgs e)
		{
			DateTime now = DateTime.Now;

			TimeSpan span = now.Subtract( tracktime );

			if ( span.Milliseconds < 200 )
				return;

			tracktime = now;

			System.Random random = new Random();

			int red = random.Next( 255 );
			int blue = random.Next( 255 );
			int green = random.Next( 255 );

			label1.ForeColor = Color.FromArgb( red, green, blue );		
		}
	}
}